'use strict';
const { fmtTime } = require('./worker');
const { createProjectCommands } = require('./projectCmd');
const { createProjectFlow } = require('./projectFlow');
const { capsText } = require('./engineCaps');
const { createSessions } = require('./sessions');
const { createMenuUi } = require('./menuUi');
const searchLib = require('./search');

// Lệnh agent (bot phụ) được dùng. Các lệnh còn lại (cập nhật, toàn quyền, kết nối máy, Google, màn hình...) chỉ ở bot quản lý.
const AGENT_CMDS = new Set(['tim', 'anh', 'nghiencuu', 've', 'taodoc', 'help', 'id', 'start', 'huy', 'nen', 'tieptuc', 'moi', 'viec', 'trangthai', 'duan', 'project', 'kynang', 'skill', 'hoantac', 'khoiphuc', 'phien', 'cho', 'dung', 'nhatky', 'hoidong', 'nho', 'quen', 'trinho', 'ai']);

function helpText(profiles) {
  return 'AgentOS - nhắn việc bằng chữ, AI sẽ làm.\n' +
    '/claude, /codex, /gemini hoặc /deepseekapi <việc> - ép dùng một AI (khóa API hoặc tài khoản) (mặc định tự chọn, hết hạn mức thì tự chuyển)\n' +
    profiles.map((p) => '/' + p.name + ' <việc> - ' + (p.description || 'dùng bộ công cụ ' + p.name) + '\n').join('') +
    '/viec [số] - xem 5 việc gần nhất, hoặc đầy đủ một việc\n' +
    '📷 /camera <tên> [câu hỏi] - chụp ảnh camera cửa hàng (có câu hỏi thì AI nhìn ảnh trả lời) · 🔌 /dien <tên> bat|tat|xem - bật/tắt ổ cắm, đèn thông minh\n' +
    '🖥️ /may - ĐỘI MÁY: xem/giao việc/cập nhật các máy AgentOS khác của cửa hàng (qua Tailscale) · /may <tên> <việc> · /may them <tên> <địa chỉ> <khóa>\n' +
    '🔑 /ketnoi <tên máy> - chép khóa SSH của máy này sang máy trong Đội máy (có nút duyệt) để chạy lệnh/chép tệp trên máy đó không cần mật khẩu\n' +
    '🔎 /tim <từ khóa> [homnay|tuan|thang] - TÌM LẠI hội thoại cũ (cả câu hỏi lẫn câu trả lời, không cần gõ đúng dấu) · /viec <số> - xem đầy đủ một việc\n' +
    '🎨 /anh <mô tả> - tạo ảnh bằng AI (cần khóa Gemini hoặc OpenAI, chỉ quản trị viên) · /anh sua <chỉnh gì> - sửa ảnh vừa tạo. Không có khóa: /ve <mô tả> để AI vẽ bằng mã. Tài liệu Word/Excel/PDF: /taodoc; nghiên cứu có trích dẫn: /nghiencuu; điều khiển màn hình máy: /dieukhien\n' +
    '🩺 /bacsi - nhờ AI phân tích các lỗi máy đang gặp và đề xuất cách sửa (máy cũng tự sửa lỗi quen thuộc như dịch vụ chết, ổ đầy, rồi báo)\n' +
    '🏛️ /hoidong <việc> - HỘI ĐỒNG AI: hai AI làm độc lập, AI thứ ba đối chiếu và kết luận (cho việc quan trọng, tốn gấp ~3 lần hạn mức)\n' +
    '📁 /duan - DỰ ÁN: mỗi dự án có thư mục tệp, chỉ dẫn, sổ tay, lịch sử riêng; mọi AI dùng chung dữ liệu dự án (Claude hết hạn mức thì Codex làm tiếp). /duan moi <tên> · /duan <tên> · /duan thoat · #<tên-dự-án> <việc>\n' +
    '--- Lệnh nhanh (không qua AI, chỉ quản trị viên) ---\n' +
    '/manhinh - chụp màn hình máy gửi về đây · /cuaso - xem các cửa sổ đang mở\n' +
    '🕹 ĐIỀU KHIỂN TỪ XA: /maytinh - tình trạng máy (CPU, RAM, ổ đĩa, nhiệt độ, dịch vụ) · /lenh <lệnh> - chạy lệnh dòng lệnh (có sudo, cần chế độ toàn quyền) · /lay <tệp> - lấy tệp từ máy gửi về đây\n' +
    '/go <chữ> · /phim <phím> · /bam <x> <y> [dup|phai] - gõ chữ, bấm phím, bấm chuột trên màn hình máy (sau mỗi thao tác bot tự chụp lại)\n' +
    '/guilen - tạo link để gửi tệp LỚN (tới 5 GB) từ điện thoại lên máy · /lay <tệp> - tệp quá 49 MB tự tạo link tải về · /tuxa - mở RustDesk, bot gửi ID + mật khẩu tạm vào đây để anh điều khiển trực tiếp từ xa (/tuxa dong để đóng) · /vao <máy> - tự đăng nhập RustDesk vào máy khác bằng mật khẩu đã lưu (nhập mật khẩu ở Cài đặt → Máy từ xa, không gửi vào chat)\n' +
    '/timchu <chữ> · /bamchu <chữ> - tìm/bấm đúng nút theo CHỮ trên màn hình (đọc chữ OCR, không cần đoán toạ độ) · /chuyen <tên cửa sổ> · /dan [chữ] - xem/chép bộ nhớ tạm của máy · /mokhoa · /doc [tệp] - đọc nội dung Word/Excel/PowerPoint/PDF (không ghi tệp thì đọc tệp anh vừa gửi) · /doi <pdf|docx|xlsx|pptx...> [tệp] - đổi định dạng · /thay <chữ cũ> | <chữ mới> - sửa chữ trong .docx/.pptx/.xlsx, gửi lại bản mới · /saoluu [nhãn|ds] - điểm khôi phục cấu hình · /bat <tên|MAC> - bật máy khác trong nhà (Wake-on-LAN)\n' +
    '/mo <zalo|deepseek|chrome|rustdesk> · /dong <ứng dụng> · /khoamay · /khoimay co · /tatmay co\n' +
    '/deepseek <việc> - mở DeepSeek web trên máy + chép sẵn câu lệnh (anh bấm Ctrl+V và Gửi)\n' +
    '/onedrive [ketnoi|dongbo|thumuc|ngat co] - OneDrive: AI đọc dữ liệu và lưu kết quả/ghi nhớ ở đó\n' +
    '/baocao [gio 21:30|tat|bat] - báo cáo doanh số, hàng sắp hết, ổ đĩa · /hen 08:00 <việc> - mỗi ngày giao việc cho AI · /hen xoa <số>\n' +
    '🔔 /canhbao - cảnh báo CHỦ ĐỘNG khi doanh số tụt bất thường hoặc có hàng mới sắp hết (bot tự nhắn, không tốn hạn mức AI) · /canhbao kiemtra\n' +
    '📘 /fanpage - AI trả lời tin nhắn FANPAGE qua API chính thức (nháp có nút ✅/❌ hoặc tự động) · /fanpage ketnoi nhờ AI tự lấy khóa · /fanpage tudong · /fanpage chidan <nội dung>\n' +
    '👤 /facebook - TRỢ LÝ TRỰC Messenger cá nhân: may [tên máy Windows] (MỘT LỆNH — dùng Chrome thật của máy Windows, khuyên dùng) · dangnhap (chỉ cách cũ, Chrome của bot) · bat · nhap (chỉ soạn nháp) · tudong [tên] (AI tự trả lời tin đơn giản, nhạy cảm vẫn chờ duyệt) · khong <tên> · chidan · chuky · nhatky · /fb tra <số> <nội dung>\n' +
    '💾 /dongbo [bat|tat|chay] [tên máy] - sao lưu 2 CHIỀU dữ liệu Claude/Codex giữa máy này và các máy con (qua SSH, tự chạy theo giờ, giữ nhiều bản)\n' +
    '🤖 /ai [claude|codex|gemini|deepseek|tudong] - xem/đổi AI ưu tiên ngay (hoặc nhắn "chuyển sang dùng codex")\n' +
    '📊 /chiphi [tuan|thang|homnay] - thống kê dùng AI theo AI và theo dự án · /chiphi tran <AI> <số việc/tháng> - đặt trần tháng (vượt thì dồn sang AI khác)\n' +
    '💾 /saoluudia [chay] - xem/chạy ngay SAO LƯU dữ liệu ra ổ USB/HDD ngoài (phòng ổ trong máy hỏng)\n' +
    '/capnhat [co|tudong bat|tudong tat] - cập nhật phần mềm AgentOS khi có bản mới (không cần boot lại)\n' +
    '/capnhat hedieuhanh [co] - cập nhật HỆ ĐIỀU HÀNH Debian (Linux, Chrome, LibreOffice...) lên bản mới nhất\n' +
    '/tailscale [ketnoi|ngat co] - đường vào dự phòng khi Telegram/mạng lỗi · /in <tệp trong OneDrive> [may <tên>] - in qua máy in của máy\n' +
    '🎙 Tin nhắn thoại: bot nghe và làm theo ("doanh số hôm nay", "tồn kho nồi chiên", "chụp màn hình"... chạy ngay; còn lại giao cho AI). Lệnh nguy hiểm (tắt máy, toàn quyền) chỉ gõ chữ mới làm được.\n' +
    '-----\n' +
    '/nhatky [tuan] - nhật ký các lần AI xin dùng công cụ và các lệnh điều khiển máy anh đã gõ; /nhatky tuan = báo cáo 7 ngày (ai nhắn, AI làm gì, bị từ chối gì); xem chi tiết trên Cài đặt → Nhật ký\n' +
    '/tuchan [nhanh|ai] - tự chẩn đoán cả máy (bot, AI, đăng nhập, ổ đĩa, màn hình, mạng...) và báo chỗ nào hỏng · /menu - MENU NÚT BẤM (khỏi nhớ lệnh) · /google - kết nối và hỏi nhanh Lịch/Gmail · /daily - quản lý agent (bot Telegram phụ chạy độc lập) · /phancung - kiểm tra phần cứng máy (RAM, ổ đĩa, card mạng/Wi-Fi, đồ họa, firmware) và chỉ cách xử lý · /log [số dòng] - xem nhật ký bộ điều phối (đã che khóa)\n' +
    '/hangrao [bat|tat] - hàng rào cho AI toàn quyền (cấm đọc khóa, hỏi trước khi gửi ra ngoài/dính tiền)\n' +
    '/nen <việc> - giao việc NỀN chạy song song (không chờ hàng đợi), xong báo riêng · /tieptuc [số việc] - làm tiếp việc bị ngắt/lỗi · /sukien - AI tự làm khi có hóa đơn mới, hàng sắp hết, hoặc webhook\n' +
    '/vaitro - phân vai cho nhân viên/kế toán (chỉ chủ máy); họ nhắn bot được nhưng việc luôn ở chế độ bảo vệ\n' +
    '/dung - NÚT DỪNG KHẨN CẤP: hủy mọi việc và ngắt điều khiển từ xa ngay\n' +
    '/trangthai - hàng đợi và tình trạng hạn mức\n' +
    '/huy - hủy việc đang chạy và các việc đang chờ\n' +
    '/toanquyen - bật chế độ TOÀN QUYỀN: AI tự làm một mạch, không hỏi xin phép, có sudo (chỉ quản trị viên)\n' +
    '/baove - quay về chế độ bảo vệ: AI hỏi trước khi ghi file/chạy lệnh (chỉ quản trị viên)\n' +
    '/moi - bắt đầu cuộc trò chuyện mới (quên ngữ cảnh cũ, GIỮ ghi nhớ lâu dài)\n' +
    '/phien - bảng các cuộc trò chuyện: đang làm / cần duyệt / xong, nút Xem · Tiếp tục · Dừng · /cheodo - chế độ quyền của dự án (hỏi từng lần · tự sửa · chỉ lập kế hoạch · chạy thẳng) · /hoantac - quay về MỐC KHÔI PHỤC của dự án khi AI sửa hỏng tệp (bot tự lưu mốc trước mỗi việc) · /kynang - KỸ NĂNG của dự án (dạy AI cách làm báo giá, chốt ca…): xem/tạo/sửa/xóa ngay trên Telegram · /dichvu - KẾT NỐI DỊCH VỤ (Notion, Lịch, Gmail…): thêm/bật/tắt/thử bằng nút, khóa nhập xong bot xóa tin ngay (chủ máy) · /cho - CHỢ KỸ NĂNG/PLUGIN: cài gói kỹ năng + kết nối dựng sẵn, tự cập nhật theo bản AgentOS (chủ máy) · /duan luat - luật cho/hỏi/cấm · /ghepdoi - người lạ nhắn bot nhận mã, chủ máy bấm Cho phép (chủ máy)\n' +
    '/nho <điều cần nhớ> · /quen <từ khóa> · /trinho · /trinho tim <từ khóa> - SỔ TAY LÂU DÀI như cuốn sách (Phần › Chương › Mục, có số), dùng chung cho mọi AI. /moi = cuộc trò chuyện mới là DỰ ÁN mới (sổ tay riêng, không mất cuộc cũ; gộp ở Cài đặt → Dự án); /moi tiep chỉ mở phiên AI mới; /moi xoa quên hẳn ngữ cảnh\n' +
    '📷 Gửi ảnh, nhiều ảnh (album), video hoặc tài liệu kèm chú thích: bot tải về, trích khung hình + lời nói trong video rồi giao AI xem (tệp tối đa 20 MB)\n' +
    '/id - xem ID Telegram của bạn';
}
const HELP = helpText([]);

const ICON = { queued: 'chờ', running: 'đang chạy', waiting: 'chờ hạn mức hồi', done: 'xong', error: 'lỗi', limit: 'hết hạn mức', cancelled: 'đã hủy', interrupted: 'bị ngắt' };

// Xử lý một tin nhắn. Trả về văn bản cần trả lời (hoặc null). Không gọi mạng trực tiếp -> dễ test.
// `profiles`: [{ name, description, adminOnly }] các bộ công cụ chọn bằng lệnh /<tên> (ví dụ /web).
// `isAdmin(uid)`: quản trị viên mới dùng được bộ adminOnly và duyệt lệnh/ghi file (mặc định: mọi người được phép).
// `approvals`: nhận lượt bấm nút duyệt.
// Lệnh điều khiển máy ghi vào /nhatky (lệnh /go chỉ ghi số ký tự vì có thể là mật khẩu)
const AUDITED = new Set(['lenh', 'lay', 'go', 'phim', 'bam', 'bamchu', 'chuyen', 'dan', 'tuxa', 'guilen', 'mo', 'dong', 'khoamay', 'khoimay', 'tatmay', 'mokhoa', 'saoluu', 'bat', 'doi', 'thay', 'hangrao', 'tuchan', 'log', 'nen', 'tieptuc', 'saoluudia', 'chiphi', 'canhbao', 'may', 'ketnoi', 'ai', 'dongbo', 'fanpage', 'facebook', 'fb', 'camera', 'dien', 'vao']);
function createBot({ db, worker, allowed, profiles, isAdmin, approvals, fullAccess, quick, voice, media, memory, send, quietAck, roles, projects, auditlog, hoidap, images, diagnose, fleet, iot, ketnoi, engineCtl, dongbo, fanpage, facebook, deleteMessage, now, access, pairing, sandboxLine, checkpoints, journal, connectorsUi, pluginsUi, skillsUi, googleStatus, agentsUi, agentMode }) {
  now = now || Date.now;
  const albums = new Map();                       // media_group_id -> { msgs, timer }: gom các ảnh/video của một album thành MỘT việc
  const ATT_KEYS = { photo: undefined, video: undefined, video_note: undefined, animation: undefined, document: undefined, caption: undefined, media_group_id: undefined };
  profiles = profiles || [];
  isAdmin = isAdmin || (() => true);
  const profileByName = new Map(profiles.map((p) => [p.name, p]));
  const help = helpText(profiles);
  const pcmd = projects ? createProjectCommands({ db, projects, isAdmin, memory, engines: () => worker.engineNames() }) : null;
  const menuUi = createMenuUi({ isAdmin, run: (m) => handle(m), send, submit: (c, t, e) => submit(c, t, e), googleStatus });
  let flow = null;                                 // điều hướng dự án: nút Tiếp tục, hỏi chọn dự án khi quay lại sau vài giờ, đặt tên dự án mới (projectFlow.js)

  // project: undefined = dự án đang chọn của cuộc trò chuyện; null = chế độ chung; chuỗi = mã dự án (cú pháp #tên)
  function submit(chatId, prompt, pref, profile, project, council) {
    const cur = pcmd ? pcmd.current(chatId) : null;
    // Chứng từ: chỉ Claude ghi được sổ qua cổng duyệt (Codex/Gemini ở chế độ chỉ đọc) nên ưu tiên Claude
    if (!pref && /^\[CHỨNG TỪ/.test(prompt) && worker.engineNames().includes('claude')) pref = 'claude';
    const proj = project === undefined ? (cur ? cur.id : null) : project;
    const id = db.addJob(chatId, prompt, pref, profile, 'main', proj, council);
    if (proj && projects && projects.markActive) projects.markActive(proj);
    const ahead = db.aheadOf(id);
    setImmediate(() => worker.wake());
    if (quietAck) return ahead > 0 ? '⏳ Đã xếp hàng (còn ' + ahead + ' việc trước đó). Gõ /huy để hủy.' : null;        // việc làm ngay: bot hiện "đang gõ" + tin trạng thái thay cho tin báo nhận
    return ahead > 0 ? 'Đã nhận việc #' + id + ' (còn ' + ahead + ' việc trước đó).' : 'Đã nhận việc #' + id + ', đang làm...';
  }

  // Đổi AI ưu tiên ngay (không sửa tệp, không khởi động lại, nhớ qua lần khởi động sau). Hết hạn mức thì vẫn tự chuyển sang AI kế.
  const noAcc = (t) => String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd');
  const AI_ALIAS = { claude: 'claude', codex: 'codex', gemini: 'gemini', deepseek: 'deepseekapi', deepseekapi: 'deepseekapi' };
  function naturalAi(text) {
    const t = noAcc(text).trim().replace(/[.!?]+$/, '');
    if (t.length > 70) return null;
    const m = /^(em |bot )?(chuyen|doi|dung|chon|bat)( han| luon)?( sang| qua)?( dung| xai)? (claude|codex|gemini|deepseek(?:api)?)( cho anh| cho toi)?( nhe| nha| di| thoi| luon| ngay)?$/.exec(t);
    return m ? m[6] : null;
  }
  function aiCommand(uid, arg) {
    if (!isAdmin(uid)) return 'Chỉ chủ máy đổi được AI.';
    if (!engineCtl) return 'Máy này chưa hỗ trợ đổi AI.';
    const a = noAcc(arg).trim();
    const label = (e) => { const x = worker.engineStatus ? worker.engineStatus().find((y) => y.name === e) : null; return x ? x.label : e; };
    if (engineCtl.original().length === 1) {             // chỉ một AI (mặc định: Claude): không có gì để đổi
      const only = engineCtl.original()[0];
      if (!a || /^(tu ?dong|mac ?dinh|reset)$/.test(a) || AI_ALIAS[a] === only) return '🤖 Máy này chỉ dùng ' + label(only) + '.\n\n' + capsText([only], label);
      return AI_ALIAS[a] ? 'Máy này chỉ dùng ' + label(only) + ' (đã bỏ ' + a + ').' : 'Không biết AI "' + String(arg).trim() + '". Máy này chỉ dùng ' + label(only) + '.';
    }
    if (!a) {
      const cur = engineCtl.order();
      return '🤖 AI đang ưu tiên: ' + cur.map(label).join(' → ') + '\nĐổi: /ai ' + engineCtl.original().map((e) => (e === 'deepseekapi' ? 'deepseek' : e)).join(' | /ai ') + ' · về thứ tự mặc định: /ai tudong\n(Hết hạn mức thì bot tự chuyển sang AI kế. Ép riêng một việc: /codex <việc>.)\n\n' + capsText(engineCtl.original(), label);
    }
    if (/^(tu ?dong|mac ?dinh|reset)$/.test(a)) { engineCtl.reset(); return '✅ Về thứ tự mặc định: ' + engineCtl.order().map(label).join(' → '); }
    const e = AI_ALIAS[a];
    if (!e) return 'Không biết AI "' + String(arg).trim() + '". Dùng: /ai claude, /ai codex, /ai gemini, /ai deepseek hoặc /ai tudong.';
    if (!engineCtl.original().includes(e)) return 'AI ' + a + ' chưa được bật trên máy này.';
    engineCtl.setPrimary(e);
    return '✅ Từ giờ dùng ' + label(e) + ' trước: ' + engineCtl.order().map(label).join(' → ') + '. Việc đang chạy giữ nguyên, việc mới theo thứ tự này. Hết hạn mức thì tự chuyển sang AI kế.';
  }

  const makeFlow = () => createProjectFlow({ db, projects, isAdmin, now, submit, send, worker, checkpoints, journal, running: (c) => db.runningInChat(c) > 0, sessions: createSessions({ db, projects, approvals, now }) });

  function handle(msg) {
    if (!msg || !msg.from || !msg.chat) return null;
    if (!flow && pcmd) flow = makeFlow();
    const text = String(msg.text || msg.caption || '').trim();
    const uid = String(msg.from.id);
    const chatId = String(msg.chat.id);

    // Người lạ: chỉ được hỏi ID của chính họ (để quản trị viên điền vào cấu hình). Còn lại im lặng.
    if (!allowed.has(uid)) {
      if (/^\/id(@\w+)?$/i.test(text)) return 'ID Telegram của bạn: ' + uid;
      return pairing ? pairing.request(msg) : null;                 // ghép ID bằng mã: trả mã cho người lạ + hỏi chủ máy (pairing.js)
    }
    if (projects && projects.noteName) { try { projects.noteName(chatId, [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ') || msg.from.username); } catch (e) { /* tên chỉ để dễ nhìn */ } }
    // Chỉ nhận chat riêng với người được phép (không nhận trong nhóm).
    if (msg.chat.type && msg.chat.type !== 'private') return null;
    // Mốc lần nhắn trước (giữ trên bản sao tin khi xử lý đệ quy: tin thoại/ảnh được chuyển thành chữ rồi gọi lại handle)
    const prevAt = flow ? (msg._prevAt !== undefined ? msg._prevAt : (msg._prevAt = flow.touch(chatId))) : 0;
    // Ảnh, video, album, tài liệu: tải về, trích khung hình + lời nói (video), gắn đường dẫn vào câu lệnh rồi xử lý như tin chữ (chú thích = yêu cầu).
    if (media && media.listAttachments(msg).length) {
      const finish = async (msgs, last) => {
        const p0 = await media.prepare(msgs);
        const p = pcmd ? pcmd.adoptFiles(chatId, uid, p0) : p0;
        const cap = msgs.map((m) => String(m.caption || m.text || '').trim()).filter(Boolean)[0] || '';
        if (!p.block) return p.errors.length ? '⚠️ ' + p.errors.join('\n') : 'Không đọc được tệp đính kèm.';
        const ct = pcmd ? pcmd.chungtuAsk(chatId, uid, cap, p.files.map((f) => f.path)) : null;
        const ask = ct || cap || 'Anh gửi tệp đính kèm. Hãy xem và mô tả ngắn gọn những gì thấy, rồi hỏi lại nếu chưa rõ anh cần làm gì.';
        const reply = await handle(Object.assign({}, last, ATT_KEYS, { text: ask + '\n\n' + p.block }));
        const warn = p.errors.length ? '⚠️ ' + p.errors.join('\n') + '\n' : '';
        if (reply && typeof reply === 'object') return Object.assign({}, reply, { text: warn + (reply.text || '') });
        return warn + (reply || '');
      };
      if (msg.media_group_id && send) {
        const g = albums.get(msg.media_group_id) || { msgs: [], timer: null };
        g.msgs.push(msg); albums.set(msg.media_group_id, g);
        clearTimeout(g.timer);
        g.timer = setTimeout(() => {
          albums.delete(msg.media_group_id);
          finish(g.msgs, g.msgs[g.msgs.length - 1]).then((r) => (r ? send(chatId, r) : null)).catch((e) => send(chatId, '⚠️ Không xử lý được album: ' + e.message).catch(() => {}));
        }, 1800);
        return null;
      }
      return finish([msg], msg);
    }
    // Tin nhắn thoại / file âm thanh: nghe thành chữ rồi xử lý như chủ máy vừa gõ (trừ lệnh nguy hiểm: không có "/" nên không bao giờ thành /tatmay...)
    const vmedia = msg.voice || msg.audio;
    if (!text && vmedia && voice) {
      if (!isAdmin(uid)) return 'Tin nhắn thoại chỉ dành cho quản trị viên.';
      if (vmedia.duration && vmedia.duration > 180) return 'Tin nhắn thoại dài quá 3 phút, anh chia nhỏ giúp em.';
      return (async () => {
        const r = await voice.transcribe(vmedia.file_id);
        if (!r.ok) return '🎙 ' + r.error;
        const said = r.text.replace(/^[\/\s]+/, '');                         // chữ nghe được không bao giờ thành lệnh "/..." tự do
        const cmdText = voice.spoken(said);
        const reply = await handle(Object.assign({}, msg, { voice: undefined, audio: undefined, text: cmdText || said }));
        const head = '🎙 Em nghe được: "' + r.text + '"' + (cmdText ? '  → ' + cmdText : '');
        if (reply && typeof reply === 'object') return Object.assign({}, reply, { text: head + (reply.text ? '\n' + reply.text : '') });
        return head + (reply ? '\n' + reply : '');
      })();
    }
    if (!text) return 'Hiện chỉ nhận tin nhắn chữ' + (voice ? ' và tin nhắn thoại' : '') + '.';

    // Đang chờ nội dung của một kỹ năng dự án (/kynang moi|sua): tin kế tiếp của chủ máy là nội dung (dòng đầu = mô tả)
    if (skillsUi && isAdmin(uid) && !text.startsWith('/') && skillsUi.wants(chatId)) return skillsUi.take(chatId, uid, text);
    // Đang chờ khóa của một kết nối dịch vụ (/dichvu): tin này là khóa → lưu rồi XÓA tin; không phải khóa thì thôi chờ và xử lý như tin thường
    if (connectorsUi && isAdmin(uid) && !text.startsWith('/') && connectorsUi.wants(chatId, text)) return connectorsUi.takeSecret(chatId, text, msg);

    // Địa chỉ đăng nhập OneDrive dán thẳng (không có lệnh): chuyển cho lệnh /onedrive
    const pending = quick && quick.match && quick.match(text);
    if (pending && !(pending.soft && !isAdmin(uid))) return isAdmin(uid) ? quick.run(pending.name, pending.arg) : 'Lệnh /' + pending.name + ' chỉ dành cho quản trị viên.';

    // "#tên-dự-án câu hỏi": hỏi một lần trong dự án đó (không đổi dự án đang chọn)
    if (projects) {
      const t = projects.parseTag(text);
      if (t) {
        if (roles && !roles.canAsk(uid)) return 'Vai của bạn (' + roles.label(uid) + ') chỉ xem được báo cáo, chưa nhắn việc cho AI được.';
        if (!projects.canUse(uid, t.project, isAdmin)) return 'Bạn chưa được gán dự án "' + t.project.name + '". Nhờ chủ máy gõ /duan giao ' + uid + '.';
        return submit(chatId, t.text, null, null, t.project.id);
      }
    }

    const cmd = text.match(/^\/(\w+)(@\w+)?\s*([\s\S]*)$/);
    if (cmd) {
      const name = cmd[1].toLowerCase();
      // AGENT (bot phụ): chỉ nhận việc và lệnh cơ bản; lệnh quản trị máy (cập nhật, toàn quyền, kết nối máy, Google...) chỉ có ở bot quản lý.
      if (agentMode && !AGENT_CMDS.has(name) && !worker.engineNames().includes(name)) return 'Lệnh /' + name + ' chỉ có ở bot quản lý. Bot này là agent: cứ nhắn việc cần làm, hoặc gõ /help.';
      if (worker.engineNames().includes(name)) {
        if (roles && !roles.canAsk(uid)) return 'Vai của bạn (' + roles.label(uid) + ') chỉ xem được báo cáo, chưa nhắn việc cho AI được.';
        const prompt = cmd[3].trim();
        return prompt ? submit(chatId, prompt, name) : 'Cách dùng: /' + name + ' <việc cần làm>';
      }
      // Lệnh nhanh không qua AI (màn hình, mở/đóng ứng dụng, DeepSeek web, KiotViet): trả về Promise
      if (quick && quick.has(name)) {
        if (!isAdmin(uid) && !(roles && roles.canQuick(uid, name)) && !(access && access.canRun(uid, name))) return 'Lệnh /' + name + ' chỉ dành cho quản trị viên' + (roles ? ' (vai của bạn: ' + roles.label(uid) + ')' : '') + '.';
        if (db.addAudit && AUDITED.has(name)) { try { db.addAudit({ tool: '/' + name, cls: 'remote', decision: 'allow', source: 'user', summary: name === 'go' ? '(' + String(cmd[3] || '').length + ' ký tự)' : String(cmd[3] || '').replace(/(token|pass\w*|mat\s?khau|secret|key)\S*\s*[=:]?\s*\S+/gi, '$1 ***') }); } catch (e) { /* nhật ký lỗi không chặn lệnh */ } }
        return quick.run(name, cmd[3], { chatId, uid });
      }
      if (profileByName.has(name)) {
        if (profileByName.get(name).adminOnly && !isAdmin(uid)) return 'Bộ công cụ /' + name + ' chỉ dành cho quản trị viên.';
        const prompt = cmd[3].trim();
        return prompt ? submit(chatId, prompt, null, name) : 'Cách dùng: /' + name + ' <việc cần làm>';
      }
      switch (name) {
        case 'claude': case 'codex': case 'gemini': case 'deepseekapi': return 'Engine ' + name + ' chưa được bật trên máy này.';
        case 'menu': return isAdmin(uid) ? menuUi.card() : help;
        case 'google': return isAdmin(uid) ? menuUi.google() : 'Chỉ chủ máy dùng được /google.';
        case 'giao': return agentsUi ? agentsUi.assignCommand(chatId, uid, cmd[3]) : 'Bot này không giao việc được (chỉ bot quản lý giao việc cho bot thường).';
        case 'daily': case 'agent': return agentsUi ? agentsUi.command(chatId, uid, cmd[3], msg) : 'Máy này chưa hỗ trợ nhiều bot.';
        case 'start': return isAdmin(uid) ? menuUi.card() : help;
        case 'help': return help;
        case 'id': return 'ID Telegram của bạn: ' + uid;
        case 'camera': {                                      // chụp ảnh camera trong cửa hàng; có câu hỏi thì AI nhìn ảnh trả lời
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /camera.';
          if (!iot) return 'Máy này chưa có điều khiển thiết bị.';
          const L = iot.list().cameras, a = String(cmd[3] || '').trim();
          if (!a) return L.length ? '📷 Camera: ' + L.map((c) => c.name).join(', ') + '\nDùng: /camera <tên> (chụp ảnh) · /camera <tên> <câu hỏi> (AI nhìn ảnh trả lời, ví dụ có khách không)' : 'Chưa có camera nào. Thêm ở Cài đặt → Thiết bị.';
          const cam = L.slice().sort((x, y) => y.name.length - x.name.length).find((c) => a.toLowerCase() === c.name.toLowerCase() || a.toLowerCase().startsWith(c.name.toLowerCase() + ' '));
          if (!cam) return 'Không có camera trong "' + a.slice(0, 30) + '". Camera có: ' + L.map((c) => c.name).join(', ');
          const q = a.slice(cam.name.length).trim();
          return iot.snapshot(cam.name).then((s) => {
            const hm = new Date(s.at + 7 * 3600 * 1000).toISOString().slice(11, 16);
            if (!q) return { text: '📷 ' + cam.name + ' lúc ' + hm, files: [{ path: s.file, name: 'camera.jpg', kind: 'photo', temp: false }] };
            const ack = submit(chatId, '[Camera "' + cam.name + '" lúc ' + hm + '] ' + q + '\n\n[Tệp đính kèm — đã lưu trên máy. Hãy xem ảnh bằng công cụ đọc ảnh rồi trả lời dựa trên ảnh]\n- Ảnh: ' + s.file, null, null, null);
            return { text: '📷 ' + cam.name + ' lúc ' + hm + (ack ? '\n' + ack : ' — đang nhờ AI xem ảnh...'), files: [{ path: s.file, name: 'camera.jpg', kind: 'photo', temp: false }] };
          }, (e) => '⚠️ ' + e.message);
        }
        case 'ai': return aiCommand(uid, String(cmd[3] || ''));
        case 'fanpage': {                                   // AI trả lời tin nhắn fanpage qua API chính thức của Meta (nháp có nút duyệt hoặc tự động)
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /fanpage.';
          if (!fanpage) return 'Máy này chưa có tính năng fanpage.';
          const a = String(cmd[3] || '').trim();
          if (/^(ketnoi|ket noi|laykhoa|lay khoa|lay api)$/.test(noAcc(a))) { return submit(chatId, fanpage.connectPrompt(), null, 'web') || '🔗 Đang nhờ AI vào Chrome lấy khóa truy cập fanpage...'; }
          return fanpage.command(a).then((r) => { if (/^them\s/i.test(noAcc(a)) && deleteMessage && msg.message_id) Promise.resolve(deleteMessage(chatId, msg.message_id)).catch(() => {}); return r; }, (e) => '⚠️ ' + e.message);
        }
        case 'facebook': {                                  // Facebook cá nhân qua Chrome đã đăng nhập: AI đọc tin, soạn nháp, gửi sau khi chủ máy duyệt
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /facebook.';
          if (!facebook) return 'Máy này chưa có tính năng Facebook.';
          return facebook.command(String(cmd[3] || ''));
        }
        case 'fb': {
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /fb.';
          if (!facebook) return 'Máy này chưa có tính năng Facebook.';
          return facebook.fbCommand(String(cmd[3] || ''));
        }
        case 'dongbo': {                                    // sao lưu 2 chiều dữ liệu Claude/Codex giữa các máy (qua SSH, không qua AI)
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /dongbo.';
          if (!dongbo) return 'Máy này chưa có đội máy.';
          return dongbo.command(String(cmd[3] || ''));
        }
        case 'may': {                                         // ĐỘI MÁY: giao việc / xem tình trạng / cập nhật máy AgentOS khác (qua Tailscale)
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /may.';
          if (!fleet) return 'Máy này chưa có đội máy.';
          const a = String(cmd[3] || '').trim(), m = a.match(/^(\S+)\s*([\s\S]*)$/), sub = m ? m[1].toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd') : '';
          if (!a) {
            return fleet.statusAll().then((l) => (l.length ? '🖥️ Đội máy:\n' + l.map((x) => (x.online ? '🟢 ' + x.name + ' · bản ' + (x.version || '?') + ' · ' + (x.queued || 0) + ' việc chờ' + (x.running ? ', đang làm #' + x.running : '') + (x.diskFreeMb != null ? ' · ổ trống ' + Math.round(x.diskFreeMb / 1024) + ' GB' : '') : '🔴 ' + x.name + ' · không liên lạc được (' + x.error + ')')).join('\n') : 'Chưa có máy con nào.') + '\n\nThêm: /may them <tên> <địa chỉ> <khóa> · Giao việc: /may <tên> <việc> · Cập nhật: /may capnhat <tên> · Xóa: /may xoa <tên>');
          }
          if (sub === 'them') { const p = m[2].trim().split(/\s+/); if (p.length < 3) return 'Cách dùng: /may them <tên> <địa chỉ http://100.x.x.x:8433> <khóa>. Địa chỉ và khóa xem ở Cài đặt của máy con → Đội máy.'; try { fleet.addMachine({ name: p[0], url: p[1], key: p[2] }); } catch (e) { return '⚠️ ' + e.message; } return '✅ Đã thêm máy "' + p[0] + '". Gõ /may để xem có liên lạc được không. (Khóa vừa gõ nằm trong lịch sử chat này: nên xóa tin nhắn đó.)'; }
          if (sub === 'xoa') return fleet.removeMachine(m[2].trim()) ? '🗑️ Đã xóa máy "' + m[2].trim() + '".' : 'Không có máy "' + m[2].trim() + '".';
          if (sub === 'capnhat') return fleet.updateMachine(m[2].trim()).then((r) => '⬆️ ' + m[2].trim() + ': ' + r.text, (e) => '⚠️ ' + e.message);
          const name = m[1], task = m[2].trim();
          if (!task) return 'Cách dùng: /may ' + name + ' <việc cần làm>';
          return fleet.sendTask(name, task).then((r) => {
            const sendBack = (t) => (send ? send(chatId, t) : Promise.resolve()).catch(() => {});
            (async () => {                                                  // chờ máy con làm xong (tối đa 15 phút) rồi gửi kết quả về đây
              for (let i = 0; i < 180; i++) {
                await new Promise((res) => setTimeout(res, 5000));
                let j; try { j = await fleet.jobResult(name, r.jobId); } catch (e) { continue; }
                if (['done', 'error', 'cancelled', 'interrupted', 'limit'].includes(j.status)) return sendBack('🖥️ ' + name + ' (việc #' + r.jobId + ' · ' + j.status + (j.engine ? ' · ' + j.engine : '') + '):\n' + (j.result || j.error || '(không có nội dung)'));
              }
              sendBack('🖥️ ' + name + ': việc #' + r.jobId + ' chưa xong sau 15 phút (vẫn có thể đang làm; hỏi lại bằng /may).');
            })();
            return '📤 Đã giao cho "' + name + '" (việc #' + r.jobId + '). Xong em báo. Việc chạy chế độ bảo vệ trên máy đó; nếu cần duyệt, nút duyệt hiện ở Telegram của máy đó.';
          }, (e) => '⚠️ Không giao được cho "' + name + '": ' + e.message);
        }
        case 'ketnoi': {                                      // chép khóa công khai SSH sang máy trong Đội máy (có nút duyệt trên Telegram)
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /ketnoi.';
          if (!ketnoi) return 'Máy này chưa có đội máy.';
          return ketnoi.request(chatId, String(cmd[3] || '').trim());
        }
        case 'bacsi': {                                    // nhờ AI chẩn đoán máy (chỉ đọc): tự chẩn đoán đầy đủ rồi giao AI giải thích nguyên nhân + đề xuất cách sửa
          if (!isAdmin(uid)) return 'Chỉ chủ máy dùng được /bacsi.';
          if (!diagnose) return 'Máy này chưa có bác sĩ máy.';
          return diagnose().then((d) => {
            if (!d.bad) return '🩺 Tự chẩn đoán: mọi thứ ổn, không có gì cần AI xem.\n' + d.report;
            const ack = submit(chatId, d.prompt, null, null, null);
            return '🩺 ' + d.bad + ' mục có vấn đề. Em đã nhờ AI phân tích nguyên nhân và đề xuất cách sửa (AI không tự sửa; lệnh cần quyền sẽ hỏi anh duyệt).' + (ack ? '\n' + ack : '');
          }, (e) => '⚠️ Không chẩn đoán được: ' + e.message);
        }
        case 'hoidong': {                                    // HỘI ĐỒNG AI: hai AI làm độc lập, AI thứ ba đối chiếu
          if (roles && !roles.canAsk(uid)) return 'Vai của bạn chỉ xem được báo cáo.';
          const prompt = String(cmd[3] || '').trim();
          if (!prompt) return 'Cách dùng: /hoidong <việc quan trọng>. Hai AI làm ĐỘC LẬP rồi AI thứ ba đối chiếu, chỉ ra chỗ khác nhau và kết luận. Tốn gấp khoảng 3 lần hạn mức nên chỉ dùng cho việc quan trọng (soạn hợp đồng, quyết định giá, số liệu thuế...).';
          if (worker.engineNames().length < 2) return 'Hội đồng cần bật ít nhất 2 AI (Cài đặt → AI và khóa API).';
          return submit(chatId, prompt, null, null, undefined, true) || '🏛️ Đã giao cho hội đồng AI (làm lâu hơn bình thường).';
        }
        case 'duan': case 'project': {
          if (!pcmd) return 'Máy này chưa hỗ trợ dự án.';
          if (!String(cmd[3] || '').trim() && flow) { const b = flow.board(chatId, uid); return { text: b.empty ? pcmd.listText(chatId, uid) : b.text, buttons: b.rows }; }       // bảng phiên: trạng thái + nút Xem/Tiếp tục/Dừng + "🆕 Dự án mới"
          return pcmd.run(chatId, uid, cmd[3]);
        }
        case 'ghepdoi': return isAdmin(uid) ? (pairing ? pairing.command(cmd[3]) : 'Máy này chưa có ghép ID bằng mã.') : 'Chỉ chủ máy dùng được /ghepdoi.';
        case 'phien': { if (!flow) return 'Máy này chưa hỗ trợ dự án.'; const b = flow.board(chatId, uid); return { text: b.empty ? 'Chưa có cuộc trò chuyện nào. Nhắn việc hoặc gõ /moi để bắt đầu.' : b.text, buttons: b.rows }; }
        case 'cheodo': case 'quyen': return flow ? flow.modeCard(chatId, uid) : 'Máy này chưa hỗ trợ dự án.';
        case 'kynang': case 'skill': return skillsUi ? skillsUi.command(chatId, uid, cmd[3]) : 'Máy này chưa hỗ trợ kỹ năng dự án.';
        case 'cho': case 'plugin': {
          if (!pluginsUi) return 'Máy này chưa hỗ trợ chợ kỹ năng.';
          return Promise.resolve(pluginsUi.command(chatId, uid, cmd[3])).then((r) => (r && r.run ? submit(chatId, r.run) : r));       // lệnh của plugin → việc mới
        }
        case 'dichvu': return connectorsUi ? connectorsUi.command(chatId, uid, cmd[3], msg) : 'Máy này chưa hỗ trợ kết nối dịch vụ.';
        case 'hoantac': case 'khoiphuc': return flow ? flow.checkCard(chatId, uid) : 'Máy này chưa hỗ trợ dự án.';
        case 'moi': {
          const cur = pcmd ? pcmd.current(chatId, uid) : null;
          const scope = chatId + (cur ? '#' + cur.id : '');            // /moi trong dự án chỉ làm mới cuộc trò chuyện CỦA dự án đó
          const wipe = /^\s*(xoa|xóa|het|hết|sach|sạch)\b/i.test(String(cmd[3] || ''));
          const same = /^\s*(tiep|tiếp)\b/i.test(String(cmd[3] || ''));
          // /moi (mặc định): cuộc trò chuyện MỚI = DỰ ÁN MỚI, mỗi dự án một cuốn sách riêng; cuộc trước giữ nguyên ở dự án cũ, gộp lại ở Cài đặt → Dự án.
          if (!wipe && !same && projects && projects.newChat) {
            const nameArg = String(cmd[3] || '').trim();
            if (cur && cur.auto && !db.lastJobId(scope) && !nameArg) return 'Cuộc trò chuyện "' + cur.name + '" còn trống, anh cứ nhắn việc (không cần mở thêm).';
            if (memory && memory.flush) memory.flush(scope);       // ghi điều đáng nhớ của cuộc trước vào sổ tay của nó
            if (!nameArg) return flow.askNew(chatId, uid, '');     // hỏi TÊN dự án mới ngay trên Telegram
            const r = flow.createNamed(chatId, uid, nameArg);      // /moi <tên>: đặt tên luôn
            if (r.err) return '⚠️ ' + r.err + ' Anh chọn tên khác giúp em.';
            return '🆕 Đã bắt đầu cuộc trò chuyện MỚI = dự án "' + r.project.name + '" (sổ tay riêng).' + (cur ? '\nCuộc trước vẫn giữ nguyên ở dự án "' + cur.name + '" (/duan để xem, bấm Tiếp tục để quay lại).' : '') +
              '\nGộp các dự án lại cho gọn: Cài đặt → Dự án → Gộp dự án. /moi tiep = chỉ mở phiên AI mới trong dự án hiện tại · /moi xoa = quên hẳn ngữ cảnh.';
          }
          db.kvDelPrefix('session:' + scope + ':');                // AI mở phiên mới (hết "lạc đề")...
          if (wipe) {                                              // /moi xoa: quên cả tóm tắt cuộc trò chuyện (sổ tay vẫn giữ, xóa bằng /quen)
            db.kvSet('ctxfrom:' + scope, db.lastJobId(scope));
            if (memory) memory.resetChat(scope);
            return cur ? 'Đã xóa ngữ cảnh và bắt đầu cuộc trò chuyện mới trong dự án "' + cur.name + '" (sổ tay vẫn giữ).' : 'Đã xóa ngữ cảnh và bắt đầu cuộc trò chuyện mới (sổ tay vẫn giữ).';
          }
          if (memory && memory.flush) memory.flush(scope);         // ...nhưng KHÔNG mất trí nhớ: ghi điều đáng nhớ vào sổ tay, giữ tóm tắt + sổ tay cho phiên mới
          return (cur ? 'Đã mở phiên AI mới trong dự án "' + cur.name + '"' : 'Đã mở phiên AI mới') + ', bộ nhớ vẫn giữ nguyên (sổ tay + tóm tắt). Muốn quên hẳn ngữ cảnh: /moi xoa.';
        }
        case 'trangthai': {
          const cur = worker.currentJobId();
          const eng = worker.engineStatus().map((e) => e.label + ': ' + (e.until ? 'hết hạn mức, hồi khoảng ' + fmtTime(e.until) : 'sẵn sàng')).join('\n');
          const full = !!(fullAccess && fullAccess.get());
          const box = sandboxLine && isAdmin(uid) ? '\n' + sandboxLine() + (full ? '\n(Chỉ áp dụng cho ID thường. Chủ máy đang TOÀN QUYỀN nên AI của chủ máy chạy ngoài hộp cô lập, không bị giới hạn mạng.)' : '') : '';          // chỉ chủ máy thấy tình trạng cô lập
          const rest = 'Đang chạy: ' + (cur ? '#' + cur : 'không có') + '\nĐang chờ: ' + db.queuedCount() +
            ' việc' + (db.waitingCount() ? ' (trong đó ' + db.waitingCount() + ' chờ hạn mức hồi)' : '') + '\n' + eng + box;
          if (!fullAccess) return rest;
          if (!fullAccess.get()) return 'Chế độ: 🛡️ bảo vệ (có hỏi duyệt)\n' + rest;
          if (!fullAccess.os) return 'Chế độ: ⚡ TOÀN QUYỀN (không hỏi, có sudo)\n' + rest;
          return fullAccess.os().then((st) => (st.ok ? 'Chế độ: ⚡ TOÀN QUYỀN (không hỏi, ĐÃ có sudo)\n' : 'Chế độ: ⚠️ TOÀN QUYỀN trong bot nhưng hệ điều hành CHƯA cấp sudo (' + st.why + '). Gõ /toanquyen co để cấp đủ.\n') + rest);
        }
        case 'tim': {                                       // ô tìm chung: mọi việc đã làm (câu hỏi + câu trả lời) + sổ tay
          let q = String(cmd[3] || '').trim();
          if (!q) return 'Cách dùng: /tim <từ khóa> [homnay|tuan|thang]. Tìm trong câu hỏi và câu trả lời của mọi việc đã làm' + (isAdmin(uid) ? ' (mọi cuộc trò chuyện) và trong sổ tay' : ' của bạn') + '. Ví dụ: /tim nồi chiên khuyến mại tuần';
          const adm = isAdmin(uid);
          const span = /\s+(homnay|hom nay|tuan|thang)\s*$/i.exec(q);
          let from = 0;
          if (span) {
            q = q.slice(0, span.index).trim();
            const vn = new Date(now() + 7 * 3600 * 1000); const mid = Date.UTC(vn.getUTCFullYear(), vn.getUTCMonth(), vn.getUTCDate()) - 7 * 3600 * 1000;
            from = /^hom/i.test(span[1]) ? mid : /^tuan/i.test(span[1]) ? now() - 7 * 86400000 : now() - 30 * 86400000;
          }
          if (!q) return 'Gõ từ khóa cần tìm, ví dụ /tim nồi chiên tuan';
          const r = searchLib.searchJobs(db.raw, q, { chatId: adm ? undefined : chatId, from, limit: 6 });
          let mem = [];
          try { if (adm && memory && memory.book) mem = searchLib.searchMemory(memory.book.list(), [], q, 4); } catch (e) { mem = []; }
          return searchLib.format(q, r, mem, { scope: (adm ? 'mọi cuộc trò chuyện' : 'hội thoại của bạn') + (span ? ' · ' + span[1].toLowerCase() : ''), now: now() });
        }
        case 'anh': {                                       // tạo ảnh bằng API (Gemini/OpenAI); /anh sua <chỉnh gì> sửa ảnh vừa tạo
          if (!images) return 'Máy này chưa có tính năng tạo ảnh.';
          if (!isAdmin(uid)) return 'Lệnh /anh chỉ dành cho quản trị viên (tạo ảnh tốn tiền theo khóa API của chủ máy).';
          let a = String(cmd[3] || '').trim();
          if (!a) return 'Cách dùng: /anh <mô tả ảnh> (thêm ngang hoặc doc ở đầu để đổi khung: /anh ngang poster khuyến mại) · /anh sua <chỉnh gì> (sửa ảnh vừa tạo, cần khóa Gemini). Chưa có khóa API: dùng /ve để AI vẽ bằng mã.';
          const day = new Date(now() + 7 * 3600 * 1000).toISOString().slice(0, 10);
          const ck = 'imgday:' + chatId + ':' + day, used = Number(db.kvGet(ck)) || 0;
          if (used >= 30) return 'Hôm nay đã tạo 30 ảnh (giới hạn mỗi ngày để tránh tốn tiền API). Mai tạo tiếp nhé.';
          let editOf = null, size = 'vuong';
          const sm = /^(sua|chinh|edit)\s+/i.exec(noAcc(a));
          if (sm) { editOf = db.kvGet('lastimg:' + chatId); if (!editOf) return 'Chưa có ảnh nào để sửa. Tạo ảnh trước bằng /anh <mô tả>.'; a = a.slice(sm[0].length).trim(); }
          const zm = /^(ngang|doc|vuong)\s+/i.exec(noAcc(a));
          if (zm) { size = zm[1].toLowerCase(); a = a.slice(zm[0].length).trim(); }
          return images.generate({ prompt: a, size, editOf }).then((r) => {
            if (!r.ok) return '⚠️ ' + r.error;
            db.kvSet(ck, used + 1); db.kvSet('lastimg:' + chatId, r.file);
            return { text: '🎨 Ảnh ' + (r.edited ? '(đã sửa) ' : '') + 'bằng ' + r.provider + '. Gõ /anh sua <chỉnh gì> để chỉnh tiếp.', files: [{ path: r.file, name: require('path').basename(r.file), kind: 'photo' }] };
          });
        }
        case 'viec': {
          const want = Number(String(cmd[3] || '').replace(/\D/g, '')) || 0;
          if (want) {                                       // /viec <số>: xem đầy đủ một việc (người thường chỉ xem việc của mình)
            const j = db.getJob(want);
            if (!j || (!isAdmin(uid) && String(j.chat_id) !== String(chatId))) return 'Không thấy việc #' + want + '.';
            const cut = (s, n) => { s = String(s || ''); return s.length > n ? s.slice(0, n) + '… (còn ' + (s.length - n) + ' ký tự)' : s; };
            return '#' + j.id + ' [' + (ICON[j.status] || j.status) + (j.engine ? ', ' + j.engine : '') + (j.profile ? ', /' + j.profile : '') + (j.project ? ', dự án ' + j.project : '') + ']\n❓ ' + cut(j.prompt, 900) + (j.result ? '\n\n💬 ' + cut(j.result, 2800) : '') + (j.error ? '\n\n⚠️ ' + cut(j.error, 500) : '');
          }
          const rows = db.recentJobs(chatId, 5);
          if (!rows.length) return 'Chưa có việc nào.';
          return rows.map((j) => '#' + j.id + ' [' + (ICON[j.status] || j.status) + (j.engine ? ', ' + j.engine : '') + (j.profile ? ', /' + j.profile : '') + '] ' + j.prompt.slice(0, 60).replace(/\s+/g, ' ')).join('\n');
        }
        case 'nhatky': {
          if (auditlog && /^(tuan|week|7)$/.test(String(cmd[3] || '').trim().toLowerCase())) return isAdmin(uid) ? auditlog.weekText(7) : 'Chỉ chủ máy xem được báo cáo tuần.';
          const rows = db.recentAudit(15);
          if (!rows.length) return 'Chưa có lần xin dùng công cụ nào.';
          const MARK = { allow: '✅', deny: '⛔' };
          const SRC = { auto: 'tự động', policy: 'bị chặn', user: 'bạn quyết', timeout: 'hết giờ', cancel: 'việc dừng', error: 'lỗi' };
          return rows.map((a) => {
            const d = new Date(a.ts), p = (n) => String(n).padStart(2, '0');
            return p(d.getHours()) + ':' + p(d.getMinutes()) + ' ' + (a.job_id == null ? 'lệnh' : '#' + a.job_id) + ' ' + (MARK[a.decision] || '?') + ' ' + (SRC[a.source] || a.source) +
              ' · ' + a.tool + ': ' + String(a.summary || '').replace(/\s+/g, ' ').slice(0, 70);
          }).join('\n');
        }
        case 'toanquyen': case 'baove': {
          if (!fullAccess) return 'Máy này chưa hỗ trợ chế độ toàn quyền.';
          if (!isAdmin(uid)) return 'Chỉ quản trị viên được đổi chế độ.';
          const on = name === 'toanquyen';
          const confirmed = /^(co|yes|ok|dong y)$/i.test(noAcc(cmd[3]).trim());
          fullAccess.set(on);
          const plainOn = '⚡ ĐÃ BẬT chế độ TOÀN QUYỀN. AI tự làm một mạch, không hỏi xin phép, được dùng sudo trên máy này. Gõ /baove để quay về chế độ có hỏi.';
          const plainOff = '🛡️ ĐÃ BẬT chế độ bảo vệ: AI hỏi bạn trước khi ghi file hoặc chạy lệnh, chạy trong hộp cô lập. Gõ /toanquyen để bật lại toàn quyền.';
          if (!fullAccess.os || !fullAccess.grant) return on ? plainOn : plainOff;
          // Cờ trong bot CHƯA đủ: dịch vụ bot bị systemd khóa (NoNewPrivileges/ProtectSystem) thì AI vẫn không sudo/ghi hệ thống/SSH được. Phải cấp ở mức hệ điều hành.
          return (async () => {
            const st = await fullAccess.os();
            if (on) {
              if (st.ok) return '⚡ ĐÃ BẬT chế độ TOÀN QUYỀN. AI tự làm một mạch, không hỏi xin phép, ĐÃ có sudo trên máy này. Gõ /baove để quay về chế độ có hỏi.';
              if (!confirmed) return '⚡ Đã bật cờ Toàn quyền trong bot, NHƯNG hệ điều hành chưa cấp sudo: ' + st.why + '. Vì vậy AI vẫn bị chặn (không sudo, không ghi ngoài thư mục bot, không SSH).\n\n👉 Gõ /toanquyen co để cấp đủ quyền cho AI (sudo không mật khẩu + gỡ khóa của dịch vụ bot). Bot tự khởi động lại khoảng 10 giây, việc đang chạy sẽ bị ngắt. Chỉ bạn (quản trị viên Telegram) ra lệnh này được; AI không tự gọi được.';
              const r = await fullAccess.grant(true);
              return r && r.ok ? '⚡ Đang cấp TOÀN QUYỀN cho hệ điều hành: sudo không mật khẩu + gỡ khóa dịch vụ. Bot khởi động lại sau ~5 giây rồi nhắn lại; từ đó AI dùng được sudo, ghi mọi nơi, SSH sang máy khác. Gõ /baove để thu hồi.' : '⚠️ Chưa cấp được quyền hệ điều hành: ' + ((r && r.error) || 'không rõ lý do');
            }
            if (!st.ok) return plainOff;
            const r = await fullAccess.grant(false);
            return '🛡️ ĐÃ BẬT chế độ bảo vệ' + (r && r.ok ? ' và THU HỒI sudo của AI (bot khởi động lại sau ~5 giây)' : ' (chưa thu hồi được sudo: ' + ((r && r.error) || 'không rõ') + ')') + '. AI hỏi bạn trước khi ghi file/chạy lệnh. Gõ /toanquyen để bật lại.';
          })();
        }
        case 'nen': {                                       // việc nền: chạy SONG SONG với hàng đợi chính
          if (roles && !roles.canAsk(uid)) return 'Vai của bạn chỉ xem được báo cáo.';
          const prompt = String(cmd[3] || '').trim();
          if (!prompt) return 'Cách dùng: /nen <việc>. Việc nền chạy song song với việc đang làm (không chờ hàng đợi), xong thì báo riêng. Không dùng chung phiên trò chuyện, nên nhờ rõ ràng đủ ý.';
          const curP = pcmd ? pcmd.current(chatId, uid) : null;
          const id = db.addJob(chatId, prompt, null, null, 'bg', curP ? curP.id : null);
          setImmediate(() => worker.wake());
          return '🧵 Đã giao việc nền #' + id + ' (chạy song song, xong em báo). Gõ /huy để hủy.';
        }
        case 'tieptuc': {                                    // làm tiếp việc bị ngắt giữa chừng (mất điện, khởi động lại) hoặc bị lỗi
          if (roles && !roles.canAsk(uid)) return 'Vai của bạn chỉ xem được báo cáo.';
          const want = Number(String(cmd[3] || '').replace(/\D/g, '')) || 0;
          const rows = db.recentJobs(chatId, 30);
          const j = want ? rows.find((r) => r.id === want) : rows.find((r) => ['interrupted', 'error', 'cancelled'].includes(r.status));
          if (!j) return want ? 'Không thấy việc #' + want + ' của anh (chỉ xem được 30 việc gần nhất).' : 'Không có việc nào bị ngắt/lỗi gần đây. Gõ /viec để xem.';
          if (!['interrupted', 'error', 'cancelled'].includes(j.status)) return 'Việc #' + j.id + ' đang ở trạng thái "' + (ICON[j.status] || j.status) + '", không cần làm tiếp.';
          const p = 'Tiếp tục việc #' + j.id + ' (trước đó bị ' + (j.status === 'interrupted' ? 'ngắt giữa chừng do máy khởi động lại' : j.status === 'error' ? 'lỗi' : 'hủy') + '). HÃY KIỂM TRA TRẠNG THÁI HIỆN TẠI (tệp đã tạo, việc đã làm) trước, chỉ làm phần CÒN DỞ, đừng lặp lại việc đã xong hay làm hai lần.\nYêu cầu gốc:\n' + j.prompt;
          return submit(chatId, p, j.engine_pref || null, j.profile || null) || '▶️ Đang làm tiếp việc #' + j.id + '...';
        }
        case 'vaitro': {                                  // phân vai: chỉ chủ máy
          if (!roles) return 'Máy này chưa có tính năng phân vai.';
          if (!isAdmin(uid)) return 'Chỉ chủ máy được phân vai.';
          const w = String(cmd[3] || '').trim().split(/\s+/).filter(Boolean);
          const sub = (w[0] || '').toLowerCase();
          if (sub === 'dat' || sub === 'them') { const r = roles.set(w[1], w[2]); return r.ok ? '✅ Đã đặt ' + w[1] + ' = ' + roles.ROLES[w[2].toLowerCase()].label + '. Người đó nhắn bot được ngay; việc của họ luôn chạy chế độ bảo vệ (không bao giờ toàn quyền).' : '⚠️ ' + r.error; }
          if (sub === 'xoa') { const r = roles.remove(w[1]); return r.ok ? (r.kept ? 'ID này nằm trong cấu hình nên vẫn được phép (đã đưa về vai Nhân viên).' : '🗑️ Đã gỡ ' + w[1] + (r.had ? '.' : ' (chưa từng có).')) : '⚠️ ' + r.error; }
          return '👥 Người dùng:\n' + roles.list().map((r) => '• ' + r.uid + ' — ' + r.label).join('\n') + '\n\nThêm/đổi: /vaitro dat <ID> <' + Object.keys(roles.ROLES).join('|') + '> (người đó gõ /id để biết ID)\nGỡ: /vaitro xoa <ID>\nXem = chỉ báo cáo · Nhân viên = báo cáo + đọc tệp + hỏi AI (chỉ đọc) · Kế toán = thêm sửa tệp Word/Excel.';
        }
        case 'dung': {                                   // NÚT DỪNG KHẨN CẤP: hủy mọi việc, ngắt điều khiển từ xa
          const queued = db.cancelQueued(chatId), running = worker.cancelRunning(chatId);
          const base = '🛑 DỪNG: ' + (running ? 'đã hủy việc đang chạy' : 'không có việc đang chạy') + (queued ? ', hủy ' + queued + ' việc đang chờ' : '') + '.';
          if (!(quick && isAdmin(uid))) return base;
          return quick.run('tuxa', 'dong').then((r) => base + '\n' + (typeof r === 'string' ? r : r.text), (e) => base + '\n⚠️ Không đóng được điều khiển từ xa: ' + e.message);
        }
        case 'huy': {
          const queued = db.cancelQueued(chatId);
          const running = worker.cancelRunning(chatId);
          if (!queued && !running) return 'Không có việc nào để hủy.';
          return 'Đã hủy' + (running ? ' việc đang chạy' : '') + (queued ? (running ? ' và ' : ' ') + queued + ' việc đang chờ' : '') + '.';
        }
        default: return 'Lệnh không có. Gõ /help để xem danh sách.';
      }
    }
    // Vai nhân viên bán hàng: tin nhắn thường = câu hỏi hỏi đáp (tra KiotViet rồi AI trả lời chỉ đọc)
    if (roles && roles.hoidapOnly && roles.hoidapOnly(uid)) {
      if (!hoidap) return 'Máy này chưa bật hỏi đáp bán hàng.';
      return hoidap.ask(chatId, text).then((r) => {
        setImmediate(() => worker.wake());
        const ahead = db.aheadOf(r.jobId);
        return quietAck ? (ahead > 0 ? '⏳ Đã xếp hàng (còn ' + ahead + ' việc trước đó).' : null) : 'Đang tra giúp bạn...';
      }, (e) => '⚠️ Chưa tra được: ' + e.message);
    }
    const asg = agentsUi ? agentsUi.tryAssign(chatId, uid, text) : null;             // "giao cho bot X làm Y" -> hộp thư của bot thường (không qua AI)
    if (asg) return asg;
    const nl = engineCtl && isAdmin(uid) ? naturalAi(text) : null;                 // "chuyển sang dùng codex" -> như /ai codex (không qua AI, không bị chặn)
    if (nl) return aiCommand(uid, nl);
    if (roles && !roles.canAsk(uid)) return 'Vai của bạn (' + roles.label(uid) + ') chỉ xem được báo cáo: gõ /doanhso hoặc /ton <sản phẩm>.';
    if (flow) { const g = flow.gate(chatId, uid, text, prevAt); if (g) return g; }       // quay lại sau vài giờ: chọn dự án trước; đang đặt tên dự án mới: tin này là tên
    return submit(chatId, text, null);
  }
  // Lượt bấm nút "Cho phép / Từ chối". Trả văn bản hiện lại cho người bấm (hoặc null nếu không phải việc của mình).
  async function handleCallback(cq) {
    if (!cq || !cq.from) return null;
    if (!allowed.has(String(cq.from.id))) return null;           // người lạ bấm nút: bỏ qua
    if (pairing && pairing.isCallback(cq.data)) return pairing.answer(cq.data, cq.from.id);
    if (menuUi.isCallback(cq.data)) return menuUi.callback(cq);
    if (agentsUi && agentsUi.isCallback(cq.data)) return agentsUi.callback(cq);
    if (connectorsUi && connectorsUi.isCallback(cq.data)) return connectorsUi.callback(cq);
    if (pluginsUi && pluginsUi.isCallback(cq.data)) return pluginsUi.callback(cq);
    if (skillsUi && skillsUi.isCallback(cq.data)) return skillsUi.callback(cq);
    if (!flow && pcmd) flow = makeFlow();
    if (flow && flow.isCallback(cq.data)) return flow.callback(cq);
    if (ketnoi && ketnoi.isCallback(cq.data)) return ketnoi.answer(cq.data, cq.from.id, isAdmin);
    if (fanpage && fanpage.isCallback(cq.data)) return isAdmin(String(cq.from.id)) ? fanpage.answerCallback(cq.data) : 'Chỉ chủ máy duyệt được.';
    if (facebook && facebook.isCallback(cq.data)) return isAdmin(String(cq.from.id)) ? facebook.answerCallback(cq.data) : 'Chỉ chủ máy duyệt được.';
    if (!approvals) return null;
    if (!/^ap:/.test(String(cq.data || ''))) return null;
    const r = await approvals.answer(cq.data, cq.from.id);
    return r.text;
  }

  return { handle, handleCallback };
}

module.exports = { createBot, HELP, helpText };
