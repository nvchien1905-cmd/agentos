'use strict';
const { runProcess, abnormal } = require('./proc');
const { classifyFailure, parseResetTime } = require('../limits');
const { lineReader, fromClaude } = require('../progress');

// Lấy đối tượng JSON kiểu {"type":"result",...} từ đầu ra của `claude -p --output-format json`.
function parseOutput(stdout) {
  const text = String(stdout || '').trim();
  if (!text) return null;
  const tryParse = (s) => { try { return JSON.parse(s); } catch (e) { return null; } };
  let v = tryParse(text);
  if (!v) {
    const lines = text.split(/\r?\n/).reverse();
    for (const l of lines) { v = tryParse(l.trim()); if (v) break; }
  }
  if (Array.isArray(v)) v = v.slice().reverse().find((x) => x && x.type === 'result') || null;
  return v && typeof v === 'object' ? v : null;
}

// Chạy một việc bằng Claude Code. Trả { done: Promise<kết quả>, kill() }.
// Kết quả: { ok, text, sessionId, costUsd, limit, resetAt, cancelled, timedOut, error }
function startClaude(opts) {
  // Có onProgress: dùng luồng sự kiện (stream-json) để báo từng bước đang làm như màn hình Claude Code; kết quả cuối lấy từ sự kiện type 'result'.
  const stream = typeof opts.onProgress === 'function';
  const args = [].concat(opts.binArgs || [], ['-p', '--output-format', stream ? 'stream-json' : 'json'], stream ? ['--verbose'] : [], stream && typeof opts.onDelta === 'function' ? ['--include-partial-messages'] : []);          // onDelta: nhận từng chữ AI đang gõ (màn hình Việc AI chạy chữ từng chữ)
  // Chế độ toàn quyền: bỏ mọi bước hỏi xin phép của Claude Code (chỉ dùng cho máy cá nhân của chủ, xem index.js FULL_HINT)
  if (opts.skipPermissions) args.push('--dangerously-skip-permissions');
  if (opts.allowedTools) args.push('--allowedTools', opts.allowedTools);
  // Công cụ MCP trả lời mọi câu hỏi xin quyền (cổng duyệt của AgentOS), ví dụ mcp__agentos_gate__approve
  if (opts.permissionPromptTool) args.push('--permission-prompt-tool', opts.permissionPromptTool);
  // File settings chứa hook PreToolUse (cổng duyệt chạy trước MỌI công cụ, kể cả lệnh Claude tự coi là an toàn)
  if (opts.settings) args.push('--settings', opts.settings);
  // Chỉ dùng đúng máy chủ MCP của bộ công cụ này, bỏ qua mọi cấu hình MCP khác trên máy.
  if (opts.mcpConfig) args.push('--mcp-config', opts.mcpConfig, '--strict-mcp-config');
  if (opts.appendSystemPrompt) args.push('--append-system-prompt', opts.appendSystemPrompt);
  if (opts.resumeId) args.push('--resume', opts.resumeId);
  if (opts.model) args.push('--model', opts.model);
  if (opts.noTools) args.push('--tools', '', '--strict-mcp-config', '--mcp-config', '{"mcpServers":{}}');            // tóm tắt/nén: không công cụ, không máy chủ MCP nào

  let finalEv = null;
  const reader = stream ? lineReader((line) => {
    let ev; try { ev = JSON.parse(line); } catch (e) { return; }
    if (ev && ev.type === 'result') finalEv = ev;
    else if (ev && ev.type === 'stream_event') { const d = ev.event && ev.event.type === 'content_block_delta' && ev.event.delta; if (d && d.type === 'text_delta' && d.text && typeof opts.onDelta === 'function') { try { opts.onDelta(d.text); } catch (e) { /* không làm hỏng việc */ } } }
    else fromClaude(ev, opts.onProgress);
  }) : null;
  const p = runProcess({ bin: opts.bin, args, cwd: opts.cwd, input: opts.prompt, timeoutMs: opts.timeoutMs, idleMs: stream ? opts.idleMs : undefined, env: opts.env, wrap: opts.wrap, onStdout: reader ? reader.push : undefined });
  const done = p.done.then((r) => {
    if (reader) reader.flush();
    const ab = abnormal(r, opts.bin);
    if (ab) return ab;
    const j = finalEv || parseOutput(r.out);
    const text = j && typeof j.result === 'string' ? j.result : '';
    const isError = !j || j.is_error === true || r.code !== 0;
    const hay = text + '\n' + r.err;
    const cls = isError ? classifyFailure(hay) : { limit: false, transient: false };
    const limit = cls.limit;
    return {
      ok: !isError,
      text,
      sessionId: j && j.session_id ? j.session_id : null,
      costUsd: j && typeof j.total_cost_usd === 'number' ? j.total_cost_usd : null,
      limit,
      transient: cls.transient,
      resetAt: limit ? parseResetTime(hay) : null,
      error: isError ? (text || r.err.trim().slice(0, 1000) || 'Thoát với mã ' + r.code) : null,
    };
  });
  return { done, kill: p.kill, pause: p.pause, resume: p.resume };
}

module.exports = { startClaude, parseOutput };
