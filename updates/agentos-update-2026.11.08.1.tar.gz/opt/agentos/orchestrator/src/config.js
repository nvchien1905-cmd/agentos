'use strict';
const fs = require('fs');
const path = require('path');

const KNOWN_ENGINES = ['claude', 'codex', 'gemini', 'deepseekapi'];

// Đọc .env đơn giản (không thêm thư viện). Biến đã có trong môi trường được ưu tiên.
function loadEnvFile(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch (e) { return; }
  for (const line of text.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}

const list = (s) => String(s || '').split(',').map((x) => x.trim()).filter(Boolean);

function load(env) {
  env = env || process.env;
  const claudeOnly = !/^(0|false|no|off|tat)$/i.test(String(env.CLAUDE_ONLY === undefined ? 'true' : env.CLAUDE_ONLY).trim());
  return {
    token: env.TELEGRAM_TOKEN || '',
    allowedUserIds: new Set(list(env.ALLOWED_USER_IDS)),
    // Quản trị viên: dùng được bộ công cụ adminOnly và duyệt lệnh/ghi file. Không đặt -> mọi người được phép đều là admin.
    adminUserIds: new Set(list(env.ADMIN_USER_IDS === undefined ? env.ALLOWED_USER_IDS : env.ADMIN_USER_IDS)),
    approvalTimeoutMs: (Number(env.APPROVAL_TIMEOUT_SEC) || 300) * 1000,
    // CHỈ DÙNG CLAUDE (mặc định, từ 2026.11.08): Codex/Gemini/DeepSeek không qua cổng duyệt và yếu hơn Claude ở việc dài → không dùng nữa. CLAUDE_ONLY=0 để dùng lại ENGINE_ORDER.
    claudeOnly: claudeOnly,
    engineOrder: claudeOnly ? ['claude'] : list(env.ENGINE_ORDER === undefined ? 'claude' : env.ENGINE_ORDER).map((s) => s.toLowerCase()),
    claudeBin: env.CLAUDE_BIN || 'claude',
    codexBin: env.CODEX_BIN || 'codex',
    geminiBin: env.GEMINI_BIN || 'gemini',
    geminiModel: env.GEMINI_MODEL || '',                         // trống = để Gemini CLI tự chọn mô hình mặc định
    geminiBinArgs: [],
    // Khóa API (xem apikeys.js): có khóa thì AI đó dùng khóa thay vì tài khoản đăng nhập
    apiKeys: require('./apikeys').keysFrom(env),
    deepseekModel: env.DEEPSEEK_MODEL || 'deepseek-flash',
    claudeBinArgs: [],
    codexBinArgs: [],
    workdir: path.resolve(env.WORKDIR || './work'),
    allowedTools: env.CLAUDE_ALLOWED_TOOLS === undefined ? 'Read,Glob,Grep' : env.CLAUDE_ALLOWED_TOOLS,
    codexSandbox: env.CODEX_SANDBOX || 'read-only',
    jobTimeoutMs: (Number(env.JOB_TIMEOUT_SEC) || 900) * 1000,
    jobIdleMs: (Number(env.JOB_IDLE_SEC) || 15 * 60) * 1000,                                   // AI không in gì quá chừng này (mặc định 15 phút) -> coi là kẹt, cắt và chạy lại không kèm phiên cũ
    jobIdleBgMs: (Number(env.JOB_IDLE_BG_SEC) || 60 * 60) * 1000,
    // Trợ lý phụ (subagents.js): AI chính giao việc cho AI phụ chạy song song. SUBAGENTS=0 để tắt
    subagents: { enabled: env.SUBAGENTS !== '0', perJob: Math.max(1, Math.min(8, Number(env.SUB_PER_JOB) || 4)), total: Math.max(1, Math.min(20, Number(env.SUB_TOTAL) || 8)) },
    // Mốc khôi phục (checkpoints.js): chụp thư mục dự án trước mỗi việc, /hoantac quay về. CHECKPOINTS=0 để tắt; CHECKPOINT_KEEP = số mốc giữ cho mỗi dự án
    checkpoints: { enabled: env.CHECKPOINTS !== '0', keep: Math.max(3, Math.min(100, Number(env.CHECKPOINT_KEEP) || 20)) },
    mainParallel: Math.max(1, Math.min(8, Number(env.PARALLEL_CHATS) || 3)),   // số ID Telegram được làm việc cùng lúc (mỗi ID vẫn làm tuần tự)
    jobTimeoutBgMs: Math.max(Number(env.JOB_TIMEOUT_BG_SEC) || 4 * 3600, Number(env.JOB_TIMEOUT_SEC) || 900) * 1000,   // việc nền /nen: mặc định 4 giờ
    limitCooldownMs: (Number(env.LIMIT_COOLDOWN_MIN) || 60) * 60 * 1000,
    dbPath: path.resolve(env.DB_PATH || './data/agentos.db'),
    // Độ bền (GĐ 5)
    // Chế độ TOÀN QUYỀN (máy cá nhân của chủ): AI chạy không hỏi xin phép, không sandbox, có sudo. Chủ đổi lúc đang chạy bằng /toanquyen và /baove (lưu trong cơ sở dữ liệu, ưu tiên hơn giá trị này).
    fullAccess: ['1', 'true', 'yes', 'on'].includes(String(env.FULL_ACCESS || '').toLowerCase()),
    // Giới hạn mạng của AI ID thường trong hộp cô lập (landlock-net.py): chỉ kết nối ra cổng web + cổng nội bộ cần thiết. NET_GUARD=0 để tắt; NET_EXTRA_PORTS=22,8080 thêm cổng được phép
    netGuard: env.NET_GUARD !== '0',
    netExtraPorts: String(env.NET_EXTRA_PORTS || '').split(',').map((x) => Number(x.trim())).filter((n) => Number.isInteger(n) && n > 0 && n < 65536),
    sandboxMode: (env.SANDBOX || 'off').toLowerCase(),                 // off | auto | bwrap (xem sandbox.js)
    sandboxHide: list(env.SANDBOX_HIDE === undefined ? '/etc/agentos' : env.SANDBOX_HIDE),
    minFreeMb: env.MIN_FREE_MB === undefined ? 300 : Number(env.MIN_FREE_MB),
    bootNotice: String(env.BOOT_NOTICE === undefined ? 'true' : env.BOOT_NOTICE).toLowerCase() !== 'false',
    jobRetentionDays: Number(env.JOB_RETENTION_DAYS) || 90,
    auditRetentionDays: Number(env.AUDIT_RETENTION_DAYS) || 180,
    outRetentionDays: Number(env.OUT_RETENTION_DAYS) || 14,
    backupKeep: Number(env.BACKUP_KEEP) || 7,
    retryDelaysMs: list(env.TRANSIENT_RETRY_SEC === undefined ? '15,60,180' : env.TRANSIENT_RETRY_SEC).map((s) => Number(s) * 1000).filter((n) => n >= 0),
    // Cấu hình công cụ (MCP + bộ công cụ). Không đặt -> chỉ dùng CLAUDE_ALLOWED_TOOLS.
    // Thư mục OneDrive (đồng bộ hai chiều): AI đọc dữ liệu và lưu kết quả/ghi nhớ ở đây
    oneDriveDir: env.ONEDRIVE_DIR || '/srv/onedrive',
    // KiotViet API chính thức (chỉ đọc) cho /doanhso và /ton
    // shops: nhiều gian hàng (KIOTVIET_SHOPS do trang Cài đặt → KiotViet ghi) + bộ khóa cũ ở ba biến bên dưới
    kiotviet: { clientId: env.KIOTVIET_CLIENT_ID || '', clientSecret: env.KIOTVIET_CLIENT_SECRET || '', retailer: env.KIOTVIET_RETAILER || '', shops: require('./kiotviet').parseShops(env) },
    reportTime: /^\d{2}:\d{2}$/.test(env.REPORT_TIME || '') ? env.REPORT_TIME : '21:30',      // giờ gửi báo cáo hằng ngày (giờ VN); đổi bằng /baocao gio
    updateUrl: env.UPDATE_URL || '',                              // nơi lấy bản cập nhật (mặc định: kho GitHub chính thức)
    // Bộ nhớ dùng chung cho mọi AI (memory.js) + nén ngữ cảnh bằng mô hình rẻ (summarizer.js) + chọn AI theo độ khó (router.js)
    memory: {
      enabled: String(env.MEMORY_ENABLED === undefined ? 'true' : env.MEMORY_ENABLED).toLowerCase() !== 'false',
      recentTurns: Number(env.MEMORY_RECENT_TURNS) || 4, rotateAfter: Number(env.MEMORY_ROTATE_AFTER) || 15,
      summarizeAfter: Number(env.MEMORY_SUMMARIZE_AFTER) || 15, factsMax: Number(env.MEMORY_FACTS_MAX) || 4500,
    },
    summaryProvider: (claudeOnly ? 'claude' : (env.SUMMARY_PROVIDER || 'auto')).toLowerCase(),         // auto (Gemini → DeepSeek → Codex) | gemini | deepseek | codex | none
    summaryModel: env.SUMMARY_MODEL || '',                                  // trống = tự chọn mô hình Gemini flash còn dùng được
    routeByDifficulty: String(env.ROUTE_BY_DIFFICULTY === undefined ? 'true' : env.ROUTE_BY_DIFFICULTY).toLowerCase() !== 'false',
    lightEngines: list(claudeOnly ? '' : (env.LIGHT_ENGINES === undefined ? 'deepseekapi,gemini' : env.LIGHT_ENGINES)).map((s) => s.toLowerCase()),
    toolsFile: env.TOOLS_FILE ? path.resolve(env.TOOLS_FILE) : '',
    chromePath: env.CHROME_PATH || '',
    display: env.DISPLAY || ':99',
  };
}

function validate(cfg) {
  const errs = [];
  if (!cfg.token) errs.push('Thiếu TELEGRAM_TOKEN');
  if (cfg.allowedUserIds.size === 0) errs.push('Thiếu ALLOWED_USER_IDS (không có ID nào được phép -> từ chối chạy)');
  for (const id of cfg.allowedUserIds) if (!/^\d+$/.test(id)) errs.push('ALLOWED_USER_IDS chứa giá trị không phải số: ' + id);
  for (const id of cfg.adminUserIds) if (!cfg.allowedUserIds.has(id)) errs.push('ADMIN_USER_IDS có ID không nằm trong ALLOWED_USER_IDS: ' + id);
  if (!['off', 'auto', 'bwrap'].includes(cfg.sandboxMode)) errs.push('SANDBOX phải là off, auto hoặc bwrap');
  if (!(cfg.minFreeMb >= 0)) errs.push('MIN_FREE_MB không hợp lệ');
  if (cfg.engineOrder.length === 0) errs.push('ENGINE_ORDER rỗng');
  for (const e of cfg.engineOrder) if (!KNOWN_ENGINES.includes(e)) errs.push('ENGINE_ORDER có engine không biết: ' + e);
  if (new Set(cfg.engineOrder).size !== cfg.engineOrder.length) errs.push('ENGINE_ORDER bị lặp engine');
  return errs;
}

module.exports = { load, loadEnvFile, validate, KNOWN_ENGINES };
