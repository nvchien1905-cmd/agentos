'use strict';
const path = require('path');

// Chính sách quyền cho từng lần AI gọi công cụ. Hàm thuần, không đụng mạng/đĩa -> dễ test.
// Kết quả decide(): { action: 'allow'|'ask'|'deny', cls, summary, reason, warn, taint, canRemember }

// ToolSearch/TodoWrite là công cụ nội bộ của Claude Code (nạp định nghĩa công cụ, ghi danh sách việc), không đụng file hay mạng.
const READ = new Set(['Read', 'Glob', 'Grep', 'LS', 'NotebookRead', 'TodoWrite', 'ToolSearch']);
const WRITE = new Set(['Edit', 'Write', 'MultiEdit', 'NotebookEdit']);
const BROWSE_WEB = new Set(['WebFetch', 'WebSearch']);
// Thao tác chỉ xem của Playwright MCP; mọi thao tác khác của trình duyệt (bấm, gõ, chạy script, tải file lên...) là "interact".
const BROWSE_ACTIONS = /^browser_(navigate|navigate_back|snapshot|take_screenshot|tabs|wait_for|console_messages|network_requests|resize|close)$/;

// Điều khiển màn hình máy (desk-mcp.js): chỉ XEM (chụp, đọc chữ, liệt kê cửa sổ) thì tự cho phép; mọi thao tác (bấm, gõ, phím, cuộn, kéo, mở ứng dụng) hỏi chủ máy, bấm "cho phép cả việc này" thì cho cả nhóm công cụ màn hình trong việc đó.
const DESK_OBSERVE = /^screen_(screenshot|info|windows|find|clipboard_get|wait)$/;
const DESK_ALL = 'mcp__desk__*';
// Lệnh `agentos-desk` vô hại (xem màn hình, mở/đóng ứng dụng trong danh sách) AI chạy thẳng, không bắt chủ máy bấm cho phép từng lần; bấm/gõ/phím vẫn hỏi. Khớp TOÀN BỘ câu lệnh (không có ; | & $ ...).
const DESK_SAFE_CMD = /^agentos-desk (?:(?:screenshot|windows|info|who)|(?:open|close) (?:chrome|webbot|fbbot|zalo|rustdesk|deepseek|chatgpt|claudeweb))$/;
const isDesk = (tool) => /^mcp__desk__/.test(tool);
const LABEL = { exec: 'Chạy lệnh', write: 'Ghi/sửa file', interact: 'Thao tác trên trang web', browse: 'Xem web', other: 'Dùng công cụ', read: 'Đọc file' };

// File chứa khóa/token/dữ liệu hệ thống: AI không bao giờ được đọc hay ghi, kể cả khi người dùng bấm cho phép.
const SECRET_RE = /(?<![\w-])(\.ssh|\.aws|\.gnupg|\.kube|\.claude|\.codex|\.config[\\/]onedrive|refresh_token|\.netrc|\.npmrc|\.git-credentials|\.env(\.[\w.-]+)?|id_rsa|id_ed25519|\.credentials\.json|orchestrator\.env|agentos\.db|shadow|passwd)(?![\w-])/i;

// Lệnh shell không bao giờ hợp lệ với tác nhân này (từ chối thẳng, không hỏi).
const EXEC_DENY = [
  [/\bsudo\b|\bsu\s+-?\w*\s*($|[;&|])|\bdoas\b/, 'nâng quyền (sudo/su)'],
  [/\|\s*(sudo\s+)?(ba|z|da|k|c)?sh\b|\|\s*(sudo\s+)?python3?\b|\|\s*(sudo\s+)?node\b|\|\s*perl\b/, 'đưa dữ liệu tải về vào shell/trình thông dịch'],
  [/\bmkfs(\.\w+)?\b|\bdd\b[^;&|]*\bof=\/dev\/|:\(\)\s*\{.*\}\s*;\s*:|\bfdisk\b|\bparted\b/, 'phá ổ đĩa'],
  [/\b(shutdown|reboot|halt|poweroff|init\s+0)\b|\bsystemctl\s+(poweroff|reboot|halt)\b/, 'tắt/khởi động lại máy'],
  [/\/dev\/(tcp|udp)\//, 'mở kết nối mạng thô'],
  [/\bchmod\s+(-R\s+)?[0-7]*777\b[^;&|]*\s\//, 'mở quyền toàn bộ hệ thống'],
  [/\bcrontab\b|\bsystemctl\s+(enable|edit|mask)\b|\/etc\/systemd\b|\.bashrc|\.profile\b|authorized_keys/, 'cài chạy ngầm / sửa cấu hình đăng nhập'],
];
const SHELL_META = /[;&|`$<>\n\\(){}]/;

function globRe(p) { return new RegExp('^' + String(p).replace(/[.+^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$'); }
const matches = (list, tool) => (list || []).some((p) => globRe(p).test(tool));
const trunc = (s, n) => { s = String(s == null ? '' : s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

function parseMcp(tool) {
  const m = /^mcp__(.+?)__(.+)$/.exec(tool);
  return m ? { server: m[1], name: m[2] } : null;
}

function classify(tool, input) {
  if (READ.has(tool)) return 'read';
  if (WRITE.has(tool)) return 'write';
  if (tool === 'Bash') return 'exec';
  if (BROWSE_WEB.has(tool)) return 'browse';
  const mcp = parseMcp(tool);
  if (mcp && mcp.server === 'agentos_todo') return 'read';
  if (mcp && mcp.server === 'agentos_cmd') return 'read';                   // bot_command/bot_help: cổng /cmd (gate.js) tự kiểm và hỏi từng lệnh nhạy cảm                  // chỉ ghi danh sách việc cần làm, không đụng gì khác
  if (mcp && /^browser/.test(mcp.server)) return BROWSE_ACTIONS.test(mcp.name) ? 'browse' : 'interact';
  if (mcp && mcp.server === 'desk') return DESK_OBSERVE.test(mcp.name) ? 'browse' : 'interact';
  return 'other';
}

function summarize(tool, input, cls) {
  input = input || {};
  if (cls === 'exec') return trunc(input.command, 400);
  if (cls === 'write') return trunc(input.file_path || input.notebook_path || '', 300);
  if (isDesk(tool)) return trunc(tool.replace(/^mcp__desk__screen_/, '') + ': ' + Object.keys(input).filter((k) => k !== 'screenshot').map((k) => k + '=' + JSON.stringify(input[k])).join(' '), 400);
  const url = input.url || input.query;
  const bits = [url, input.element, input.text, input.ref, input.function, input.key].filter(Boolean);
  const name = (parseMcp(tool) || {}).name || tool;
  if (bits.length) return trunc(name + ': ' + bits.join(' | '), 400);
  return trunc(name + ' ' + JSON.stringify(input), 400);
}

function privateIPv4(a, b) {
  return a === 0 || a === 10 || a === 127 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) ||
    (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127) || a >= 224;
}

// Chặn truy cập mạng nội bộ / metadata đám mây (SSRF). Hostname phân giải ra IP nội bộ (DNS rebinding) thì chưa bắt được.
function checkUrl(u, allowPrivate) {
  let url;
  try { url = new URL(String(u)); } catch (e) { return 'địa chỉ không hợp lệ'; }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return 'chỉ cho phép http/https (không ' + url.protocol + ')';
  if (allowPrivate) return null;
  const h = url.hostname.toLowerCase().replace(/^\[|\]$/g, '');
  if (h === 'localhost' || /\.(localhost|local|internal|lan|home|corp)$/.test(h)) return 'địa chỉ mạng nội bộ';
  if (h.includes(':')) {
    if (h === '::1' || h === '::' || /^f[cd]/.test(h) || /^fe[89ab]/.test(h) || /^::ffff:/.test(h)) return 'địa chỉ mạng nội bộ';
    return null;
  }
  const m = h.match(/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/);
  if (m && privateIPv4(Number(m[1]), Number(m[2]))) return 'địa chỉ mạng nội bộ';
  return null;
}

function originOf(u) { try { return new URL(String(u)).origin; } catch (e) { return null; } }

function pathsOf(input) {
  input = input || {};
  return [input.file_path, input.path, input.notebook_path, /^[\\/]|^[a-zA-Z]:/.test(String(input.pattern || '')) ? input.pattern : null].filter(Boolean).map(String);
}
function inside(workdir, p) {
  const root = path.resolve(workdir);
  const full = path.resolve(root, p);
  const rel = path.relative(root, full);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

/**
 * ctx: { tool, input, policy, workdir, state: { tainted, allowed:Set } }
 * policy (trong profile): { allow:[mẫu tên công cụ], ask:[...], deny:[...], allowExec:[regex lệnh an toàn], allowPrivateNetwork }
 */
function decide(ctx) {
  const tool = ctx.tool, input = ctx.input || {}, pol = ctx.policy || {}, state = ctx.state || { tainted: false, allowed: new Set() };
  const cls = classify(tool, input);
  const out = { action: 'ask', cls, summary: summarize(tool, input, cls), reason: '', warn: '', taint: false, canRemember: false };
  if (isDesk(tool)) out.label = 'Điều khiển màn hình máy';
  const deny = (reason) => Object.assign(out, { action: 'deny', reason });

  // 1. Cấm cứng
  for (const p of pathsOf(input)) {
    if (SECRET_RE.test(p)) return deny('không được đụng vào file chứa khóa/token/dữ liệu hệ thống');
    // Thư mục làm việc + các thư mục dữ liệu được cho thêm (OneDrive của chủ máy). Đường dẫn tương đối tính từ thư mục làm việc.
    if ((cls === 'read' || cls === 'write') && ![ctx.workdir].concat(ctx.extraDirs || []).some((d) => inside(d, p))) return deny('chỉ được làm việc trong thư mục làm việc hoặc thư mục OneDrive');
  }
  if (cls === 'exec') {
    const cmd = String(input.command || '');
    if (SECRET_RE.test(cmd)) return deny('lệnh đụng vào file chứa khóa/token/dữ liệu hệ thống');
    for (const [re, why] of EXEC_DENY) if (re.test(cmd)) return deny('lệnh bị cấm: ' + why);
  }
  if (input.url !== undefined && (cls === 'browse' || cls === 'interact' || cls === 'other')) {
    const bad = checkUrl(input.url, pol.allowPrivateNetwork);
    if (bad) return deny('không truy cập được: ' + bad);
  }
  if (matches(pol.deny, tool)) return deny('bộ công cụ này cấm công cụ đó');

  const tainted = !!state.tainted;
  const risky = cls === 'exec' || cls === 'write' || cls === 'other';
  if (tainted && (cls === 'exec' || cls === 'write' || cls === 'other' || cls === 'interact')) {
    out.warn = 'Việc này đã đọc nội dung từ web. Nếu yêu cầu này bạn không ngờ tới, có thể do trang web cài vào: hãy từ chối.';
  }

  // 2. Tự cho phép
  if (cls === 'read') return Object.assign(out, { action: 'allow' });
  if (cls === 'browse') {
    // Chống rò dữ liệu qua địa chỉ URL: sau khi đã đọc web, chuyển sang trang web CHƯA ghé trong việc này thì hỏi lại (tùy chọn).
    const origin = pol.askNewOrigin && tainted && input.url ? originOf(input.url) : null;
    if (origin && !(state.origins && state.origins.has(origin))) {
      out.warn = 'Nội dung trang đang yêu cầu chuyển sang một trang web mới (' + origin + '). Nếu bạn không ngờ tới, có thể do trang cài vào: hãy từ chối.';
      out.taint = true;
      return out;
    }
    return Object.assign(out, { action: 'allow', taint: true });
  }
  if (matches(pol.ask, tool)) return finishAsk(out, cls, tainted);
  // "Cho phép cả việc này" chỉ có hiệu lực với thao tác trình duyệt; lệnh và ghi file luôn hỏi từng lần.
  if (cls === 'interact' && state.allowed && (state.allowed.has(tool) || (isDesk(tool) && state.allowed.has(DESK_ALL)))) return Object.assign(out, { action: 'allow', taint: true });
  if (cls === 'exec') {
    const cmd = String(input.command || '').trim();
    if (DESK_SAFE_CMD.test(cmd)) return Object.assign(out, { action: 'allow' });
    const safe = !tainted && !SHELL_META.test(cmd) && (pol.allowExec || []).some((r) => { try { return new RegExp(r).test(cmd); } catch (e) { return false; } });
    if (safe) return Object.assign(out, { action: 'allow' });
  }
  if (matches(pol.allow, tool) && !(tainted && (cls === 'exec' || cls === 'write'))) {
    return Object.assign(out, { action: 'allow', taint: cls === 'interact' });
  }
  return finishAsk(out, cls, tainted, risky);
}

// ---- HÀNG RÀO cho chế độ TOÀN QUYỀN: AI vẫn tự làm mọi việc, riêng ba nhóm sau không tự làm được:
//  1. CẤM CỨNG: đọc khóa/token/biến môi trường (chứa API key), cấu hình bí mật của AgentOS, và mọi việc lấy thông tin/điều khiển ĐIỆN THOẠI (adb, scrcpy, kdeconnect, SMS...).
//  2. HỎI CHỦ MÁY (nút bấm trên Telegram): nhắn/gửi thư cho NGƯỜI KHÁC (email, Telegram/Zalo/Slack/Facebook API). Gửi dữ liệu qua mạng (git push, scp, POST...) thì KHÔNG hỏi.
//  3. HỎI CHỦ MÁY khi XÓA (rm, git clean, gỡ phần mềm, DROP/DELETE FROM...).
//  4. (MẶC ĐỊNH TẮT từ 2026.11.18) việc dính tiền (ngân hàng, thanh toán, ví điện tử, "chuyển khoản"): chỉ HỎI chủ máy khi đặt GUARD_MONEY=ask trong orchestrator.env. Lý do: chữ "thanh toán" xuất hiện trong báo cáo/lệnh bình thường (KiotViet, sổ quỹ) nên bot cứ xin duyệt oan.
// Đây là "hàng rào chặn thói quen xấu và chặn bị lừa qua nội dung web/email", KHÔNG phải bức tường tuyệt đối: AI đã có sudo nên người cố tình vẫn vòng được.
const GUARD_DENY_CMD = [
  [/\b(printenv|export\s+-p|declare\s+-x|compgen\s+-e)\b|(^|[;&|(]\s*)env\s*($|[|;&>)])|\/proc\/[^\s]*\/environ/, 'đọc biến môi trường (chứa khóa API)'],
  [/\/etc\/agentos(\/|\b)|orchestrator\.env|\.agentos-update|signing-private|update-pubkey/, 'đọc cấu hình bí mật của AgentOS'],
];
// ĐIỆN THOẠI: bot không được lấy thông tin hay điều khiển điện thoại (cầu Android/iPhone, nhắn SMS, kết nối điện thoại với máy)
GUARD_DENY_CMD.push([/(^|[\s;&|(\/])(adb|fastboot|scrcpy|kdeconnect-cli|kdeconnect-app|kdeconnectd|gammu|gammu-smsd|mmcli|idevice[a-z_]*|ifuse|ideviceinstaller|pymobiledevice3?|jmtpfs|go-mtpfs|simple-mtpfs|mtp-[a-z]+|termux-[a-z-]+|airdroid|vysor)(\s|$)|gvfs\/mtp|mtp:\/\/|gio\s+mount\s+[^\n]*(mtp|gphoto)/i, 'đụng vào điện thoại (lấy thông tin hoặc điều khiển điện thoại)']);
// XÓA: hỏi chủ máy trước (chỉ rm tệp trong /tmp thì cho qua)
const DELETE_CMD = /(^|[\s;&|(])(rm|rmdir|unlink|shred|trash|trash-put|gio\s+trash)(\s|$)|\bfind\b[^\n]*(\s-delete\b|-exec\s+rm\b)|\bgit\s+(clean|branch\s+-D|reset\s+--hard|checkout\s+--\s)|\btruncate\b|\bdocker\s+(rm|rmi|system\s+prune|volume\s+rm)\b|\bsystemctl\s+(disable|mask)\b|\bapt(-get)?\s+(remove|purge|autoremove)\b|\b(DROP\s+(TABLE|DATABASE)|TRUNCATE\s+TABLE|DELETE\s+FROM)\b|\bnpm\s+(uninstall|rm)\b|\bcurl\b[^|;&\n]*\s-X\s*DELETE\b|\bpip3?\s+uninstall\b/i;
const DELETE_TMP_OK = /^\s*rm\s+(-[a-zA-Z]+\s+)*(\/tmp\/[^\s;&|<>$`()]+\s*)+$/;
const PHONE_WIN_RE = /scrcpy|phone\s*link|your\s*phone|kde\s*connect|điện thoại|dien thoai|android|iphone|airdroid|vysor|mtp\b/i;
// CHỈ hỏi chủ máy khi NHẮN/GỬI THƯ cho người khác (khách). Trao đổi DỮ LIỆU với chủ máy/hệ thống (git push, scp, rsync, curl POST, upload, publish) KHÔNG bị hỏi (chủ máy chốt 2026.11.18).
const GUARD_SEND_CMD = [
  [/\b(sendmail|mailx?|mutt|msmtp|swaks|ssmtp)\b/, 'gửi email'],
  [/api\.telegram\.org|openapi\.zalo\.me|oauth\.zaloapp\.com|graph\.facebook\.com|hooks\.slack\.com|discord(app)?\.com\/api|api\.line\.me|api\.twilio\.com|api\.sendgrid\.com|smtp\./i, 'gửi tin nhắn/thư qua dịch vụ bên ngoài'],
];
// Từ trong tên công cụ của kết nối dịch vụ cho thấy việc ghi/gửi/xóa (so khớp theo TỪ sau khi tách snake_case/camelCase/kebab, nên "get_dataset" không bị tính là "set")
const CONNECTOR_SIDE_EFFECT = new Set(['send', 'post', 'reply', 'forward', 'publish', 'create', 'update', 'delete', 'remove', 'trash', 'move', 'upload', 'share', 'write', 'append', 'insert', 'modify', 'patch', 'invite', 'cancel', 'import', 'label', 'archive', 'add', 'set', 'edit', 'rename', 'duplicate', 'copy', 'draft', 'comment', 'notify', 'run', 'execute', 'trigger', 'schedule', 'book', 'pay', 'transfer', 'put', 'clear', 'empty', 'unsubscribe', 'mark']);
const MONEY_RE =/(vietcombank|vcbdigibank|techcombank|bidv|vietinbank|mbbank|tpbank|vpbank|sacombank|agribank|hdbank|ocb\.com|momo\.vn|zalopay|vnpay|paypal|stripe\.com|payoneer|binance|coinbase|e-?banking|internet banking|chuyển khoản|chuyen khoan|chuyển tiền|chuyen tien|thanh toán|thanh toan|wire transfer)/i;

const moneyAsk = () => String(process.env.GUARD_MONEY || '').toLowerCase() === 'ask';
function decideGuard(ctx) {
  const tool = ctx.tool, input = ctx.input || {};
  const cls = classify(tool, input);
  const out = { action: 'allow', cls, summary: summarize(tool, input, cls), reason: '', warn: '', taint: false, canRemember: false };
  const deny = (reason) => Object.assign(out, { action: 'deny', reason });
  const ask = (warn) => Object.assign(out, { action: 'ask', warn });
  for (const p of pathsOf(input)) if (SECRET_RE.test(p)) return deny('không được đụng vào file chứa khóa/token/dữ liệu hệ thống');
  if (cls === 'exec') {
    const cmd = String(input.command || '');
    if (SECRET_RE.test(cmd)) return deny('lệnh đụng vào file chứa khóa/token/dữ liệu hệ thống');
    for (const [re, why] of GUARD_DENY_CMD) if (re.test(cmd)) return deny('không được ' + why);
    for (const [re, why] of GUARD_SEND_CMD) if (re.test(cmd)) return ask('Việc nhạy cảm: ' + why + '. Chỉ cho phép nếu chính anh vừa yêu cầu; nếu không ngờ tới (có thể do nội dung web/email/tệp cài vào) hãy từ chối.');
    if (DELETE_CMD.test(cmd) && !(DELETE_TMP_OK.test(cmd) && !cmd.includes('..'))) return ask('Việc XÓA/gỡ: lệnh này có thể xóa dữ liệu hoặc gỡ phần mềm. Chỉ cho phép nếu chính anh vừa yêu cầu; nếu không ngờ tới (có thể do nội dung web/email/tệp cài vào) hãy từ chối.');
    if (moneyAsk() && MONEY_RE.test(cmd)) return ask('Việc dính tới tiền (ngân hàng/thanh toán/chuyển khoản). Chỉ cho phép nếu chính anh yêu cầu.');
  }
  // Kết nối dịch vụ (connectors.js, máy chủ MCP "c_<mã>"): công cụ có tác dụng GHI/GỬI/XÓA ra dịch vụ bên ngoài luôn hỏi chủ máy; công cụ chỉ đọc/tìm thì để qua
  const conn = /^mcp__c_([a-z0-9]+)__(.+)$/.exec(tool);
  if (conn) {
    const words = conn[2].replace(/([a-z0-9])([A-Z])/g, '$1_$2').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
    const hit = words.find((w) => CONNECTOR_SIDE_EFFECT.has(w));
    if (hit) return ask('Kết nối "' + conn[1] + '" muốn làm việc có tác dụng ra ngoài: ' + conn[2] + '. Chỉ cho phép nếu chính anh vừa yêu cầu; nếu không ngờ tới (có thể do nội dung web/email/tệp cài vào) hãy từ chối.');
  }
  if (moneyAsk() && input.url !== undefined && (cls === 'browse' || cls === 'interact' || cls === 'other') && MONEY_RE.test(String(input.url))) return ask('Trang ngân hàng/thanh toán: thao tác ở đây có thể liên quan tới tiền. Chỉ cho phép nếu chính anh yêu cầu.');
  return out;
}

function finishAsk(out, cls, tainted) {
  // Cho "cho phép trong việc này" chỉ với thao tác trình duyệt; lệnh và ghi file luôn hỏi từng lần.
  out.canRemember = cls === 'interact';
  out.taint = cls === 'interact';
  return out;
}

module.exports = { PHONE_WIN_RE, DELETE_CMD, DESK_SAFE_CMD, DESK_OBSERVE, DESK_ALL, isDesk, decideGuard, GUARD_DENY_CMD, GUARD_SEND_CMD, MONEY_RE, decide, classify, summarize, checkUrl, originOf, inside, globRe, SECRET_RE, EXEC_DENY, LABEL, trunc };
