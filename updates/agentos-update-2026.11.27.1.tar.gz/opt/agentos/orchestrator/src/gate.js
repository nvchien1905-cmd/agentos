'use strict';
const http = require('http');
const crypto = require('crypto');
const { decide, decideGuard, originOf } = require('./policy');
const { classify: classifyCmd } = require('./cmdTool');

// Cổng duyệt: máy chủ HTTP chỉ nghe ở 127.0.0.1. Claude Code hỏi cổng (qua MCP gate-mcp.js và
// --permission-prompt-tool) trước mỗi lần dùng công cụ chưa được cho phép sẵn.
//   POST /gate  header x-gate-token  body {jobId, tool, input}  ->  {behavior:'allow',updatedInput} | {behavior:'deny',message}
const HUMAN_WAIT_MS = 12 * 60 * 1000;
function createGate({ db, approvals, workdir, log, extraDirs, dirsFor, autoAllow, kiotviet: kv, perms, sub, journal, cmd, noAsk }) {
  log = log || (() => {});
  const token = crypto.randomBytes(24).toString('hex');
  const jobs = new Map();     // jobId -> { job, policy, state:{tainted, allowed:Set} }
  let server = null;

  function audit(jobId, tool, d, decision, source) {
    try { db.addAudit({ jobId, tool, cls: d.cls, decision, source, summary: d.summary }); } catch (e) { log('ghi nhật ký lỗi: ' + e.message); }
  }

  // Nhật ký "trước khi sửa" (journal.js): thao tác được CHO PHÉP thì lưu bản gốc của tệp sắp bị sửa/xóa TRƯỚC khi công cụ chạy (hook chờ kết quả này). Lỗi ghi nhật ký không chặn việc.
  async function evaluate(body) {
    const r = await decideOne(body);
    if (journal && r && r.behavior === 'allow') {
      const entry = jobs.get(Number(body.jobId));
      if (entry) { try { await journal.before(entry.job, String(body.tool || ''), body.input && typeof body.input === 'object' ? body.input : {}); } catch (e) { log('nhật ký trước-khi-sửa lỗi: ' + e.message); } }
    }
    return r;
  }

  async function decideOne(body) {
    const entry = jobs.get(Number(body.jobId));
    if (!entry) return { behavior: 'deny', message: 'Việc không còn chạy, từ chối.' };
    const tool = String(body.tool || '');
    const input = body.input && typeof body.input === 'object' ? body.input : {};
    if (entry.journalOnly) return { behavior: 'allow', updatedInput: input };            // hàng rào tắt: chỉ ghi nhật ký, không hỏi/chặn gì
    // Luật CẤM của dự án thắng mọi thứ (kể cả tự cho phép)
    if (perms) { let why = null; try { why = perms.denies(entry.job, tool, input); } catch (e) { why = null; } if (why) { audit(entry.job.id, tool, { cls: 'policy', summary: String(input.command || input.file_path || input.url || '') }, 'deny', 'policy'); return { behavior: 'deny', message: 'Bị chặn: ' + why + '. Đừng thử lại cách này; báo người dùng nếu cần.' }; } }
    // Thao tác đã được chủ máy cho phép sẵn bằng cấu hình (vd. ghi sổ chứng từ của dự án bật chế độ chứng từ): tự cho phép, vẫn ghi nhật ký
    if (!entry.guard && autoAllow) { let ok = false; try { ok = !!autoAllow(entry.job, tool, input); } catch (e) { ok = false; } if (ok) { audit(entry.job.id, tool, { cls: 'auto', summary: String(input.command || input.file_path || '') }, 'allow', 'auto'); return { behavior: 'allow', updatedInput: input }; } }
    let d = (entry.guard ? decideGuard : decide)({ tool, input, policy: entry.policy, workdir, extraDirs: entry.extraDirs || extraDirs, state: entry.state });
    // Chế độ quyền + luật cho/hỏi của dự án (không bao giờ nới thứ chính sách đã cấm cứng)
    if (!entry.guard && perms) { try { const ov = perms.apply(entry.job, tool, input, d); if (ov) d = Object.assign({}, d, ov); } catch (e) { log('chế độ quyền dự án lỗi: ' + e.message); } }

    if (d.action === 'deny') {
      audit(entry.job.id, tool, d, 'deny', 'policy');
      return { behavior: 'deny', message: 'Bị chặn: ' + d.reason + '. Đừng thử lại cách này; báo người dùng nếu cần.' };
    }
    const noteVisit = () => { if (d.cls === 'browse' && input.url) { const o = originOf(input.url); if (o) entry.state.origins.add(o); } };
    if (d.action === 'allow') {
      if (d.taint) entry.state.tainted = true;
      noteVisit();
      if (!entry.guard) audit(entry.job.id, tool, d, 'allow', 'auto');          // chế độ hàng rào: không ghi từng thao tác cho phép (quá nhiều)
      return { behavior: 'allow', updatedInput: input };
    }
    const r = await approvals.request(entry.job, tool, d);   // đã ghi nhật ký trong approvals
    if (!r.allowed) {
      const why = r.source === 'timeout' ? 'người dùng không trả lời kịp' : r.source === 'user' ? 'người dùng từ chối' : 'không xin được quyền';
      return { behavior: 'deny', message: 'Không được phép (' + why + '). Đừng thử lại; hãy báo cho người dùng và dừng bước này.' };
    }
    if (d.taint) entry.state.tainted = true;
    noteVisit();
    if (r.remember && d.canRemember) { entry.state.allowed.add(tool); if (/^mcp__desk__/.test(tool)) entry.state.allowed.add('mcp__desk__*'); }
    return { behavior: 'allow', updatedInput: input };
  }

  // KiotViet CHỈ ĐỌC cho AI (qua API chính thức, khóa nằm ở bộ điều phối, AI không bao giờ thấy khóa): chỉ việc của chủ máy, đang chạy, mới được hỏi.
  async function kiotvietCall(body) {
    const entry = jobs.get(Number(body.jobId));
    if (!entry) return { ok: false, error: 'Việc không còn chạy.' };
    if (!kv || !kv.api || !kv.api.configured()) return { ok: false, error: 'Chưa cấu hình KiotViet API (KIOTVIET_CLIENT_ID/SECRET/RETAILER).' };
    if (kv.allowed && !kv.allowed(entry.job)) return { ok: false, error: 'Việc này không được phép đọc dữ liệu KiotViet.' };
    try { return { ok: true, data: await kv.api.rawGet(String(body.path || ''), body.shop ? String(body.shop) : undefined) }; } catch (e) { return { ok: false, error: e.message }; }
  }

  // LỆNH CỦA BOT cho AI (công cụ bot_command, cmdTool.js): chủ máy nhắn bằng lời, AI chạy lệnh thay. cmd = { run(job, text) -> {text, files}, isAdmin(chatId), help() -> text }
  // Chỉ việc của chủ máy. safe: chạy luôn · normal: chạy luôn nếu việc CHƯA đọc nội dung web, đã đọc web thì hỏi · danger: LUÔN hỏi chủ máy bằng nút bấm.
  async function cmdCall(body) {
    const entry = jobs.get(Number(body.jobId));
    if (!entry) return { ok: false, error: 'Việc không còn chạy.' };
    if (!cmd || !cmd.run) return { ok: false, error: 'Máy này chưa hỗ trợ chạy lệnh của bot qua AI.' };
    if (!cmd.isAdmin(String(entry.job.chat_id))) return { ok: false, error: 'Chỉ việc của chủ máy (quản trị viên) mới chạy được lệnh của bot.' };
    if (body.help === true) return { ok: true, text: cmd.help ? await cmd.help(entry.job) : 'Gõ /help trên Telegram để xem lệnh.' };
    const c = classifyCmd(body.command);
    if (!c.ok) return { ok: false, error: c.error };
    const tainted = !!(entry.state && entry.state.tainted);
    const d = { action: 'ask', cls: 'other', label: 'Chạy lệnh của bot', summary: c.text, reason: '', warn: '', taint: false, canRemember: false };
    if (c.level === 'danger') d.warn = '⚠️ Lệnh nhạy cảm: ' + c.why + '. Chỉ cho phép nếu chính anh vừa nhờ làm việc này.';
    else if (c.level === 'normal' && tainted) d.warn = 'Việc này đã đọc nội dung từ web. Nếu anh không ngờ tới lệnh này, có thể do trang web cài vào: hãy từ chối.';
    let skip = false; try { skip = !!(noAsk && noAsk(entry.job)); } catch (e) { skip = false; }          // việc của chủ máy ở chế độ toàn quyền: không hỏi lại (chủ máy đã chọn)
    const needAsk = !skip && (c.level === 'danger' || (c.level === 'normal' && tainted));
    if (needAsk) {
      const r = await approvals.request(entry.job, 'bot_command', d);
      if (!r.allowed) return { ok: false, error: 'Chủ máy không cho phép lệnh này (' + (r.source === 'timeout' ? 'không trả lời kịp' : 'đã từ chối') + '). Đừng thử lại; báo chủ máy và dừng bước này.' };
    } else audit(entry.job.id, 'bot_command', d, 'allow', 'auto');
    try { const out = await cmd.run(entry.job, c.text); return { ok: true, text: String((out && out.text) || '').slice(0, 3500), files: (out && out.files) || 0 }; }
    catch (e) { log('bot_command lỗi: ' + e.message); return { ok: false, error: 'Lệnh báo lỗi: ' + String(e && e.message || e).slice(0, 300) }; }
  }

  // NHỜ NGƯỜI LÀM MỘT BƯỚC (CAPTCHA, mã OTP, xác minh, đăng nhập...): AI KHÔNG vượt các bước này; nó dừng tại chỗ, nhắn chủ máy kèm nút "Em xong rồi", CHỜ rồi làm tiếp trong CÙNG một việc (không phải giao lại từ đầu).
  // Chờ tối đa HUMAN_WAIT_MS (< hạn "im lặng" 15 phút của việc để không bị coi là kẹt). Hết giờ/bỏ qua → AI nhận kết quả và dừng, báo chủ máy.
  async function humanCall(body) {
    const entry = jobs.get(Number(body.jobId));
    if (!entry) return { ok: false, error: 'Việc không còn chạy.' };
    if (!cmd || !cmd.isAdmin || !cmd.isAdmin(String(entry.job.chat_id))) return { ok: false, error: 'Chỉ việc của chủ máy mới nhờ được.' };
    const reason = String(body.reason || '').replace(/\s+/g, ' ').trim().slice(0, 500);
    if (!reason) return { ok: false, error: 'Thiếu nội dung: nói rõ anh cần làm gì.' };
    const d = { action: 'ask', cls: 'other', label: 'Cần anh làm một bước', summary: reason + '\n\nGõ /manhinh để xem màn hình máy. Làm xong bấm nút bên dưới, em sẽ làm tiếp ngay.', warn: '', taint: false, canRemember: false,
      human: { yes: '✅ Em xong rồi, làm tiếp', no: '❌ Bỏ qua, dừng việc này', timeoutMs: HUMAN_WAIT_MS } };
    const r = await approvals.request(entry.job, 'ask_human', d);
    if (r.allowed) return { ok: true, done: true, text: 'Chủ máy báo ĐÃ LÀM XONG bước đó. Hãy chụp/đọc lại trang để kiểm tra rồi làm tiếp.' };
    return { ok: true, done: false, text: r.source === 'timeout' ? 'Chủ máy chưa trả lời kịp (' + Math.round(HUMAN_WAIT_MS / 60000) + ' phút). Hãy DỪNG việc này và báo rõ bước cần làm; đừng thử vượt.' : 'Chủ máy chọn bỏ qua bước này. Hãy dừng việc và báo lại ngắn gọn.' };
  }

  // Trợ lý phụ (subagents.js): chỉ AI chính của một việc đang chạy mới gọi được
  async function subCall(body) {
    if (!sub || !sub.enabled()) return { ok: false, error: 'Tính năng trợ lý phụ đang tắt.' };
    const pid = Number(body.jobId);
    try {
      if (body.op === 'spawn') return sub.spawn(pid, body.task, body.engine ? String(body.engine) : '');
      if (body.op === 'wait') return await sub.wait(pid, Array.isArray(body.ids) ? body.ids.map(Number) : [], body.sec);
      if (body.op === 'list') return sub.list(pid);
      if (body.op === 'cancel') return sub.cancel(pid, body.id);
      return { ok: false, error: 'Lệnh không hợp lệ.' };
    } catch (e) { log('trợ lý phụ lỗi: ' + e.message); return { ok: false, error: 'Lỗi nội bộ: ' + e.message }; }
  }

  function handler(req, res) {
    const send = (code, obj) => { res.writeHead(code, { 'content-type': 'application/json' }); res.end(JSON.stringify(obj)); };
    if (req.method !== 'POST' || (req.url !== '/gate' && req.url !== '/kiotviet' && req.url !== '/sub' && req.url !== '/cmd' && req.url !== '/human')) return send(404, { error: 'not found' });
    const given = Buffer.from(String(req.headers['x-gate-token'] || ''));
    const want = Buffer.from(token);
    if (given.length !== want.length || !crypto.timingSafeEqual(given, want)) return send(401, { error: 'unauthorized' });
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > 1024 * 1024) { req.destroy(); } else chunks.push(c); });
    req.on('end', async () => {
      let body;
      try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch (e) { return send(400, { error: 'bad json' }); }
      if (req.url === '/kiotviet') return send(200, await kiotvietCall(body));
      if (req.url === '/sub') return send(200, await subCall(body));
      if (req.url === '/cmd') return send(200, await cmdCall(body));
      if (req.url === '/human') return send(200, await humanCall(body));
      try { send(200, await evaluate(body)); } catch (e) { log('cổng lỗi: ' + e.message); send(200, { behavior: 'deny', message: 'Lỗi nội bộ của cổng duyệt, từ chối.' }); }
    });
  }

  return {
    token,
    evaluate,
    // Gọi trước khi chạy engine / sau khi xong. `profile.policy` là chính sách của bộ công cụ.
    // dirsFor(job): thư mục được đọc/ghi riêng cho việc này (việc trong DỰ ÁN chỉ được làm trong thư mục dự án); trả null = dùng chung extraDirs
    begin(job, profile, opts) { jobs.set(job.id, { job, extraDirs: dirsFor ? dirsFor(job) : null, guard: !!(opts && opts.guard), journalOnly: !!(opts && opts.journalOnly), policy: profile.policy || {}, state: { tainted: false, allowed: new Set(), origins: new Set() } }); },
    end(jobId) { jobs.delete(jobId); if (approvals) approvals.cancelJob(jobId); },
    state(jobId) { const e = jobs.get(jobId); return e ? e.state : null; },
    listen(port) {
      return new Promise((resolve, reject) => {
        server = http.createServer(handler);
        server.once('error', reject);
        server.listen(port || 0, '127.0.0.1', () => resolve(server.address().port));
      });
    },
    close() { return new Promise((r) => (server ? server.close(() => r()) : r())); },
  };
}

module.exports = { createGate };
