'use strict';
// KiotViet qua API CHÍNH THỨC (chỉ đọc): doanh số theo ngày/tuần/tháng và tồn kho. Ổn định hơn nhiều so với để AI bấm chuột trên trang KiotViet.
// Cấu hình trong /etc/agentos/orchestrator.env: KIOTVIET_CLIENT_ID, KIOTVIET_CLIENT_SECRET, KIOTVIET_RETAILER (tên cửa hàng).
const API = 'https://public.kiotapi.com';
const TOKEN_URL = 'https://id.kiotviet.vn/connect/token';
const STATUS_DONE = 1;                      // hóa đơn "Hoàn thành"

const noAccent = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
const money = (n) => Math.round(Number(n) || 0).toLocaleString('vi-VN') + 'đ';
const pad = (n) => String(n).padStart(2, '0');

// Ngày theo giờ Việt Nam (UTC+7), không phụ thuộc múi giờ của máy.
function vnDate(offsetDays, nowMs) {
  const d = new Date((nowMs === undefined ? Date.now() : nowMs) + 7 * 3600 * 1000 + (offsetDays || 0) * 86400000);
  return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate(), dow: d.getUTCDay(), iso: d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()), show: pad(d.getUTCDate()) + '/' + pad(d.getUTCMonth() + 1) + '/' + d.getUTCFullYear() };
}

const DAY_MS = 86400000;
const dayMs = (iso) => Date.UTC(+iso.slice(0, 4), +iso.slice(5, 7) - 1, +iso.slice(8, 10));
const isoOf = (ms) => { const d = new Date(ms); return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); };
const showIso = (iso) => iso.slice(8, 10) + '/' + iso.slice(5, 7) + '/' + iso.slice(0, 4);

// Hiểu cách người dùng gõ khoảng thời gian: "", "hôm nay", "hôm qua", "tuần", "tháng", hoặc khoảng ngày tùy ý (dạng nội bộ "tu20261101den20261106", có thể có tiền tố "tungngay " = hiện từng ngày).
function parseRange(arg, nowMs) {
  let a = noAccent(arg), daily = false;
  if (/^tungngay\b/.test(a)) { daily = true; a = a.replace(/^tungngay\s*/, ''); }
  const c = a.match(/^tu(\d{8})den(\d{8})$/);
  let r;
  if (c) {
    const f = c[1].slice(0, 4) + '-' + c[1].slice(4, 6) + '-' + c[1].slice(6), e = c[2].slice(0, 4) + '-' + c[2].slice(4, 6) + '-' + c[2].slice(6);
    r = { key: 'tuychon', title: 'từ ' + showIso(f) + ' đến ' + showIso(e), from: f, to: isoOf(dayMs(e) + DAY_MS) };
  } else r = parseBasicRange(a, nowMs);
  return r && daily ? Object.assign(r, { daily: true }) : r;
}
function parseBasicRange(arg, nowMs) {
  const a = noAccent(arg);
  if (!a || /^(hom nay|nay|homnay|today)$/.test(a)) { const t = vnDate(0, nowMs); return { key: 'homnay', title: 'hôm nay (' + t.show + ')', from: t.iso, to: vnDate(1, nowMs).iso }; }
  if (/^(hom qua|qua|homqua|yesterday)$/.test(a)) { const t = vnDate(-1, nowMs); return { key: 'homqua', title: 'hôm qua (' + t.show + ')', from: t.iso, to: vnDate(0, nowMs).iso }; }
  if (/^(tuan|tuan nay)$/.test(a)) { const t = vnDate(0, nowMs); const back = (t.dow + 6) % 7; const s = vnDate(-back, nowMs); return { key: 'tuan', title: 'tuần này (từ ' + s.show + ')', from: s.iso, to: vnDate(1, nowMs).iso }; }
  if (/^(thang|thang nay)$/.test(a)) { const t = vnDate(0, nowMs); return { key: 'thang', title: 'tháng này (' + pad(t.m) + '/' + t.y + ')', from: t.y + '-' + pad(t.m) + '-01', to: vnDate(1, nowMs).iso }; }
  return null;
}

// Các nhóm dữ liệu AI được ĐỌC qua API (không có ghi/sửa/xóa: chỉ GET)
const READ_PATHS = new Set(['invoices', 'products', 'customers', 'branches', 'categories', 'orders', 'purchaseorders', 'returns', 'suppliers', 'users', 'pricebooks', 'transfers', 'trademarks', 'salechannels', 'vouchers', 'cashflow', 'surchages', 'bankaccounts', 'productattributes']);
function checkReadPath(raw) {
  const s = String(raw || '').trim();
  if (!s.startsWith('/') || s.startsWith('//') || /\.\.|[\s\\]/.test(s) || /^\/[a-z]+:/i.test(s)) return { ok: false, error: 'Đường dẫn KiotViet không hợp lệ: ' + s.slice(0, 80) + ' (ví dụ /invoices?pageSize=20)' };
  const seg = s.slice(1).split(/[/?]/)[0].toLowerCase();
  if (!READ_PATHS.has(seg)) return { ok: false, error: 'Nhóm "' + seg + '" không nằm trong danh sách được đọc: ' + [...READ_PATHS].join(', ') };
  return { ok: true, path: s };
}

// Câu hỏi doanh số tự nhiên ("báo cáo doanh thu từng chi nhánh Tulibaby hôm nay") -> khoảng thời gian + từ khóa lọc chi nhánh
const RANGE_RE = /\b(hom nay|hom qua|tuan nay|thang nay|today|yesterday|tuan|thang)\b/;
const FILLER = new Set('doanh thu so bao cao kiem tra cua tung moi cac chi nhanh ngay em anh cho va nhe giup xem lay tat ca tong ket hom nay qua biet hay la nao xin dum minh toi voi theo bao nhieu thi ra the nhi di tu den hien tai bay gio hang'.split(' '));
const DATE_RE = /(\d{1,2})[/.-](\d{1,2})(?:[/.-](\d{4}|\d{2}))?(?!\d)/g;
function splitRevenueQuery(arg, nowMs) {
  const nowY = vnDate(0, nowMs).y, today = vnDate(0, nowMs).iso;
  const found = [];
  const raw = String(arg || '').replace(DATE_RE, (s, d, mo, y) => {   // "1/11/2026", "01-11", "1.11.26"
    const yy = y ? (y.length === 2 ? 2000 + Number(y) : Number(y)) : nowY, iso = yy + '-' + pad(mo) + '-' + pad(d);
    if (Number(mo) < 1 || Number(mo) > 12 || Number(d) < 1 || isoOf(dayMs(iso)) !== iso) return s;   // không phải ngày thật (31/02, 13/13)
    found.push(iso); return ' ';
  });
  let t = noAccent(raw);
  const tok = t.match(/\btu(\d{8})den(\d{8})\b/);   // dạng nội bộ khi gian hàng nhận lại từ bộ chọn nhiều gian
  if (tok) { t = t.replace(tok[0], ' '); found.push(tok[1].slice(0, 4) + '-' + tok[1].slice(4, 6) + '-' + tok[1].slice(6), tok[2].slice(0, 4) + '-' + tok[2].slice(4, 6) + '-' + tok[2].slice(6)); }
  const daily = /\b(tung ngay|moi ngay|theo ngay|hang ngay|tungngay)\b/.test(t);
  t = t.replace(/\btungngay\b/g, ' ');
  const pre = daily ? 'tungngay ' : '';
  const m = t.match(RANGE_RE);
  const rest = t.replace(RANGE_RE, ' ').split(' ').filter((w) => w && !FILLER.has(w));
  if (found.length) {
    let a = found[0], b = found.length > 1 ? found[1] : today;
    if (b < a) { const x = a; a = b; b = x; }
    return { range: pre + 'tu' + a.replace(/-/g, '') + 'den' + b.replace(/-/g, ''), filter: rest.filter((w) => !/^\d+$/.test(w)).join(' ') };
  }
  if (!m && rest.some((w) => /^\d+$/.test(w) || w === 'nam' || w === 'ngoai')) return { range: t, filter: '' };   // khoảng thời gian không hỗ trợ: để parseRange báo không hiểu
  return { range: pre + (m ? m[1] : ''), filter: rest.join(' ') };
}

function createKiotViet(o) {
  o = o || {};
  const f = o.fetch || fetch;
  const cfg = { id: o.clientId || '', secret: o.clientSecret || '', retailer: o.retailer || '' };
  let token = null, tokenExp = 0;

  async function getToken() {
    if (token && Date.now() < tokenExp) return token;
    let r;
    for (let i = 0; ; i++) {
      r = await f(TOKEN_URL, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({ scopes: 'PublicApi.Access', grant_type: 'client_credentials', client_id: cfg.id, client_secret: cfg.secret }) });
      if (r.status === 429 && i < 3) { await sleep([2000, 5000, 12000][i]); continue; }
      break;
    }
    if (!r.ok) throw new Error('KiotViet từ chối đăng nhập API (HTTP ' + r.status + '). Kiểm tra KIOTVIET_CLIENT_ID / KIOTVIET_CLIENT_SECRET.');
    const d = await r.json();
    token = d.access_token; tokenExp = Date.now() + ((d.expires_in || 3600) - 120) * 1000;
    return token;
  }
  // KiotViet giới hạn tốc độ (429): gọi từng yêu cầu một, cách nhau một chút, gặp 429 thì chờ rồi thử lại; kết quả giống nhau trong 60 giây dùng lại
  const sleep = o.sleep || ((ms) => new Promise((res) => setTimeout(res, ms)));
  const GAP_MS = o.gapMs === undefined ? 250 : o.gapMs, RETRY_WAITS = o.retryWaits || [2000, 5000, 12000, 25000];
  const cache = new Map();
  let chain = Promise.resolve();
  const queued = (fn) => { const p = chain.then(fn, fn); chain = p.then(() => sleep(GAP_MS), () => sleep(GAP_MS)); return p; };
  async function fetchOnce(pathAndQuery) {
    let tokenRetried = false;
    for (let i = 0; ; i++) {
      const r = await f(API + pathAndQuery, { headers: { Authorization: 'Bearer ' + (await getToken()), Retailer: cfg.retailer } });
      if (r.status === 401 && !tokenRetried) { tokenRetried = true; token = null; continue; }
      if (r.status === 429 && i < RETRY_WAITS.length) {
        const ra = Number(r.headers && r.headers.get && r.headers.get('retry-after'));
        await sleep(ra > 0 && ra <= 60 ? ra * 1000 : RETRY_WAITS[i]); continue;
      }
      if (!r.ok) throw new Error('KiotViet lỗi ' + r.status + (r.status === 429 ? ' (bị giới hạn tốc độ, đã thử lại nhiều lần)' : '') + ' khi đọc ' + pathAndQuery.split('?')[0]);
      return r.json();
    }
  }
  async function get(pathAndQuery) {
    const hit = cache.get(pathAndQuery);
    if (hit && Date.now() - hit.at < 60000) return hit.v;
    const v = await queued(() => fetchOnce(pathAndQuery));
    cache.set(pathAndQuery, { at: Date.now(), v });
    if (cache.size > 200) for (const k of cache.keys()) { if (Date.now() - cache.get(k).at > 60000) cache.delete(k); }
    return v;
  }

  return {
    configured: () => !!(cfg.id && cfg.secret && cfg.retailer),
    parseRange,

    // Đọc thẳng một đường dẫn API công khai (CHỈ phương thức GET, chỉ các nhóm dữ liệu trong READ_PATHS) cho AI dùng thay vì đăng nhập web KiotViet.
    async rawGet(pathAndQuery) {
      const p = checkReadPath(pathAndQuery);
      if (!p.ok) throw new Error(p.error);
      return get(p.path);
    },

    async revenue(arg, nowMs) {
      const q = splitRevenueQuery(arg, nowMs);
      const range = parseRange(q.range, nowMs);
      if (!range) return 'Khoảng thời gian không hiểu được. Gõ: /doanhso (hôm nay), /doanhso hôm qua, /doanhso tuần, /doanhso tháng, /doanhso từ 1/11/2026 đến hôm nay, thêm "từng ngày" để xem theo ngày; thêm tên chi nhánh để lọc, ví dụ /doanhso hôm nay tulibaby';
      if ((dayMs(range.to) - dayMs(range.from)) / DAY_MS > 62) return 'Khoảng thời gian dài quá (tối đa 62 ngày một lần). Anh chia nhỏ ra giúp em, ví dụ từng tháng.';
      const all = [];
      for (let cur = 0; cur < 20000; cur += 100) {
        const qs = new URLSearchParams({ pageSize: '100', currentItem: String(cur), fromPurchaseDate: range.from, toPurchaseDate: range.to, orderBy: 'purchaseDate', orderDirection: 'Asc' });
        const d = await get('/invoices?' + qs.toString());
        const items = d.data || [];
        all.push(...items);
        if (items.length < 100 || all.length >= (d.total || 0)) break;
      }
      // KiotViet có thể trả cả ngày kế tiếp ở biên: lọc lại theo ngày mua
      let inRange = all.filter((i) => { const day = String(i.purchaseDate || '').slice(0, 10); return day >= range.from && day < range.to; });
      let note = '';
      if (q.filter) {
        // Chỉ những từ THẬT SỰ có trong tên chi nhánh mới dùng để lọc (từ thừa như "biết", "giúp" bị bỏ qua, không làm mất kết quả).
        const branchWords = new Set(inRange.flatMap((i) => noAccent(i.branchName).split(' ')));
        const words = q.filter.split(' ').filter((w) => branchWords.has(w));
        const unknown = q.filter.split(' ').filter((w) => !branchWords.has(w));
        if (words.length) inRange = inRange.filter((i) => { const b = noAccent(i.branchName); return words.every((w) => b.includes(w)); });
        else if (unknown.length) note = 'ℹ️ Không có chi nhánh nào tên "' + unknown.join(' ') + '", nên hiện tất cả chi nhánh.\n';
      }
      const done = inRange.filter((i) => i.status === STATUS_DONE);
      const cancelled = inRange.filter((i) => i.status !== STATUS_DONE).length;
      if (!done.length) return '📊 Doanh số ' + range.title + ': chưa có hóa đơn hoàn thành nào.' + (cancelled ? ' (' + cancelled + ' hóa đơn đã hủy/chưa hoàn thành)' : '');
      const by = new Map();
      for (const i of done) { const k = i.branchName || 'Chi nhánh ?'; const e = by.get(k) || { n: 0, sum: 0 }; e.n += 1; e.sum += Number(i.total) || 0; by.set(k, e); }
      const rows = [...by.entries()].sort((a, b) => b[1].sum - a[1].sum).map(([k, e]) => '• ' + k + ': ' + e.n + ' hóa đơn · ' + money(e.sum));
      const total = done.reduce((s, i) => s + (Number(i.total) || 0), 0);
      if (range.daily) {
        const days = new Map();
        for (let ms = dayMs(range.from); ms < dayMs(range.to); ms += DAY_MS) days.set(isoOf(ms), new Map());
        for (const i of done) {
          const d = days.get(String(i.purchaseDate || '').slice(0, 10)); if (!d) continue;
          const k = i.branchName || 'Chi nhánh ?'; const e = d.get(k) || { n: 0, sum: 0 }; e.n += 1; e.sum += Number(i.total) || 0; d.set(k, e);
        }
        const line = (day, d, detail) => {
          const sum = [...d.values()].reduce((s, e) => s + e.sum, 0), n = [...d.values()].reduce((s, e) => s + e.n, 0);
          if (!n) return day.slice(8) + '/' + day.slice(5, 7) + ': chưa có hóa đơn';
          const per = detail ? [...d.entries()].sort((a, b) => b[1].sum - a[1].sum).map(([k, e]) => k + ' ' + money(e.sum) + ' (' + e.n + ')').join(' · ') + ' → ' : '';
          return day.slice(8) + '/' + day.slice(5, 7) + ': ' + per + money(sum) + (detail ? '' : ' (' + n + ' hóa đơn)');
        };
        const foot = ['Cả kỳ:', ...rows, 'Tổng: ' + done.length + ' hóa đơn · ' + money(total) + (cancelled ? '  (không tính ' + cancelled + ' hóa đơn hủy/chưa hoàn thành)' : ''), 'Tính theo tiền hàng sau giảm giá của hóa đơn hoàn thành. Số trong ngoặc = số hóa đơn.'];
        let out = [note + '📊 Doanh số từng ngày ' + range.title, ...[...days.entries()].map(([day, d]) => line(day, d, true)), '', ...foot].join('\n');
        if (out.length > 3800) out = [note + '📊 Doanh số từng ngày ' + range.title, ...[...days.entries()].map(([day, d]) => line(day, d, false)), '', ...foot].join('\n');
        return out;
      }
      return [note + '📊 Doanh số ' + range.title, ...rows, 'Tổng: ' + done.length + ' hóa đơn · ' + money(total) + (cancelled ? '  (không tính ' + cancelled + ' hóa đơn hủy/chưa hoàn thành)' : ''),
        'Tính theo tiền hàng sau giảm giá của hóa đơn hoàn thành.'].join('\n');
    },

    // Sản phẩm sắp hết: tổng tồn các chi nhánh <= mức tồn tối thiểu đã đặt trong KiotViet (chỉ tính sản phẩm có đặt mức tối thiểu > 0).
    // Hóa đơn của hôm nay (giờ VN), mới nhất cuối: dùng cho sự kiện "hóa đơn mới"
    async invoicesToday(nowMs) {
      const from = vnDate(0, nowMs).iso, to = vnDate(1, nowMs).iso;
      const all = [];
      for (let cur = 0; cur < 5000; cur += 100) {
        const qs = new URLSearchParams({ pageSize: '100', currentItem: String(cur), fromPurchaseDate: from, toPurchaseDate: to, orderBy: 'purchaseDate', orderDirection: 'Asc' });
        const d = await get('/invoices?' + qs.toString());
        const items = d.data || [];
        all.push(...items);
        if (items.length < 100 || all.length >= (d.total || 0)) break;
      }
      return all.map((i) => ({ id: i.id, code: i.code, total: i.total, status: i.status, branchName: i.branchName, customerName: i.customerName, purchaseDate: i.purchaseDate }));
    },

    async lowStock(limit, maxPages) {
      const out = [];
      for (let page = 0, cur = 0; page < (maxPages || 60); page++, cur += 100) {
        const qs = new URLSearchParams({ pageSize: '100', currentItem: String(cur), includeInventory: 'true', isActive: 'true' });
        const d = await get('/products?' + qs.toString());
        const items = d.data || [];
        for (const p of items) {
          const inv = p.inventories || [];
          const min = inv.reduce((m, x) => Math.max(m, Number(x.minQuantity) || 0), 0);
          if (min <= 0) continue;
          const sum = inv.reduce((s, x) => s + (Number(x.onHand) || 0), 0);
          if (sum <= min) out.push({ name: p.name || '?', code: p.code || '?', onHand: sum, min });
        }
        if (items.length < 100 || cur + 100 >= (d.total || 0)) break;
      }
      out.sort((a, b) => (a.onHand - a.min) - (b.onHand - b.min));
      return { total: out.length, items: out.slice(0, limit || 15) };
    },

    // Hóa đơn trong khoảng ngày [from, to) (YYYY-MM-DD) dạng gọn, dùng cho cảnh báo doanh số (alerts.js)
    async invoiceTotals(from, to) {
      const all = [];
      for (let cur = 0; cur < 20000; cur += 100) {
        const qs = new URLSearchParams({ pageSize: '100', currentItem: String(cur), fromPurchaseDate: from, toPurchaseDate: to, orderBy: 'purchaseDate', orderDirection: 'Asc' });
        const d = await get('/invoices?' + qs.toString());
        const items = d.data || [];
        all.push(...items.map((i) => ({ id: i.id, total: i.total, status: i.status, branchName: i.branchName, purchaseDate: i.purchaseDate })));
        if (items.length < 100 || all.length >= (d.total || 0)) break;
      }
      return all;
    },


    // Thống kê hàng hóa (chỉ số lượng, KHÔNG giá vốn): số mã đang bán, còn/hết hàng, tồn theo chi nhánh, 10 mã tồn nhiều nhất. arg = lọc theo tên/mã (tùy chọn).
    async catalog(arg) {
      const q = String(arg || '').trim();
      const all = [];
      for (let cur = 0; cur < 30000; cur += 100) {
        const qs = new URLSearchParams({ pageSize: '100', currentItem: String(cur), includeInventory: 'true', isActive: 'true' });
        if (q) qs.set('name', q);
        const d = await get('/products?' + qs.toString());
        const items = d.data || [];
        all.push(...items);
        if (items.length < 100 || all.length >= (d.total || 0)) break;
      }
      if (!all.length) return 'Không có sản phẩm nào' + (q ? ' khớp "' + q + '"' : '') + '.';
      const byBranch = new Map(); let inStock = 0, totalQty = 0; const rows = [];
      for (const p of all) {
        const inv = p.inventories || []; let sum = 0;
        for (const x of inv) { const n = Number(x.onHand) || 0; sum += n; if (n > 0) { const b = byBranch.get(x.branchName || '?') || { qty: 0, skus: 0 }; b.qty += n; b.skus++; byBranch.set(x.branchName || '?', b); } }
        if (sum > 0) inStock++; totalQty += sum; rows.push({ name: p.name || '?', code: p.code || '?', sum });
      }
      rows.sort((a, b) => b.sum - a.sum);
      const lines = ['📦 Hàng hóa KiotViet' + (q ? ' "' + q + '"' : '') + ': ' + all.length + ' mã đang bán',
        '• Còn hàng: ' + inStock + ' mã · hết hàng ở mọi chi nhánh: ' + (all.length - inStock) + ' mã · tổng tồn ' + totalQty.toLocaleString('vi-VN') + ' cái',
        '• Tồn theo chi nhánh:'].concat([...byBranch.entries()].sort((a, b) => b[1].qty - a[1].qty).map(([n, b]) => '   – ' + n + ': ' + b.qty.toLocaleString('vi-VN') + ' cái (' + b.skus + ' mã)'),
        ['• 10 mã tồn nhiều nhất:'], rows.slice(0, 10).map((r) => '   – ' + r.name + ' (' + r.code + '): ' + r.sum));
      return lines.join(String.fromCharCode(10));
    },

    // Danh sách sản phẩm có giá + tồn theo chi nhánh (dùng cho hỏi đáp bán hàng)
    async products(query, limit) {
      const q = String(query || '').trim(); if (q.length < 2) return [];
      const qs = new URLSearchParams({ name: q, includeInventory: 'true', pageSize: String(limit || 5) });
      const d = await get('/products?' + qs.toString());
      return (d.data || []).slice(0, limit || 5).map((p) => {
        const inv = (p.inventories || []).filter((x) => Number(x.onHand) !== 0).map((x) => ({ name: x.branchName, onHand: Number(x.onHand) }));
        return { name: p.name || '?', code: p.code || '?', price: p.basePrice, branches: inv, total: (p.inventories || []).reduce((s, x) => s + (Number(x.onHand) || 0), 0) };
      });
    },

    async stock(query) {
      const q = String(query || '').trim();
      if (q.length < 2) return 'Cách dùng: /ton <tên hoặc mã sản phẩm>, ví dụ /ton nồi chiên';
      const qs = new URLSearchParams({ name: q, includeInventory: 'true', pageSize: '6' });
      let d = await get('/products?' + qs.toString());
      let items = d.data || [];
      if (!items.length && /^[A-Za-z0-9._-]+$/.test(q)) {                         // gõ mã sản phẩm
        try { const p = await get('/products/code/' + encodeURIComponent(q)); if (p && p.id) items = [p]; } catch (e) { /* không có mã đó */ }
      }
      if (!items.length) return 'Không thấy sản phẩm nào khớp "' + q + '".';
      const out = items.slice(0, 5).map((p) => {
        const inv = (p.inventories || []).filter((x) => Number(x.onHand) !== 0).map((x) => x.branchName + ': ' + Number(x.onHand));
        const sum = (p.inventories || []).reduce((s, x) => s + (Number(x.onHand) || 0), 0);
        return '• ' + (p.name || '?') + ' (' + (p.code || '?') + ') · giá ' + money(p.basePrice) + '\n   Tồn: ' + (inv.length ? inv.join(' · ') + ' → tổng ' + sum : 'hết hàng ở mọi chi nhánh');
      });
      return '📦 Tồn kho "' + q + '"' + (d.total > 5 ? ' (5/' + d.total + ' sản phẩm đầu)' : '') + '\n' + out.join('\n');
    },
  };
}

// NHIỀU GIAN HÀNG KiotViet (mỗi gian = một cửa hàng KiotViet riêng: Retailer + khóa API riêng, ví dụ Tulibaby và Huyền Anh).
// shops: [{ name, retailer, clientId, clientSecret }]. Cùng giao diện với createKiotViet nên chỗ khác trong bot dùng y hệt.
// Câu hỏi có tên gian ("doanh thu Tulibaby hôm nay") thì chỉ hỏi gian đó; không nêu tên thì hỏi tất cả và ghi rõ từng gian.
function createMultiKiotViet(shops, o) {
  o = o || {};
  const list = (shops || []).filter((s) => s && s.clientId && s.clientSecret && s.retailer).map((s, i) => {
    const name = String(s.name || s.retailer).trim();
    return { name, retailer: s.retailer, words: noAccent(name + ' ' + s.retailer).split(' ').filter(Boolean), api: createKiotViet({ clientId: s.clientId, clientSecret: s.clientSecret, retailer: s.retailer, fetch: o.fetch, sleep: o.sleep, gapMs: o.gapMs, retryWaits: o.retryWaits }), idx: i };
  });
  const multi = list.length > 1;
  const names = () => list.map((s) => s.name).join(', ');

  // Tách từ khóa chọn gian ra khỏi câu: trả { chosen: [gian], rest: phần còn lại }
  function choose(text) {
    const ws = noAccent(text).split(' ').filter(Boolean);
    const hit = list.filter((s) => s.words.some((w) => w.length >= 3 && !FILLER.has(w) && ws.includes(w)));   // bỏ từ thường như "anh" (đại từ) khỏi so khớp tên gian
    if (!hit.length) return { chosen: list, rest: String(text || ''), named: false };
    const used = new Set(); hit.forEach((s) => s.words.forEach((w) => { if (!FILLER.has(w)) used.add(w); }));
    return { chosen: hit, rest: ws.filter((w) => !used.has(w)).join(' '), named: true };
  }
  // chạy fn trên từng gian, lỗi một gian không làm hỏng các gian khác
  async function each(chosen, fn) {
    const out = [];
    for (const s of chosen) { try { out.push({ s, v: await fn(s.api, s) }); } catch (e) { out.push({ s, err: e.message }); } }
    return out;
  }
  const head = (s) => '🏬 ' + s.name;

  return {
    configured: () => list.length > 0,
    shops: () => list.map((s) => ({ name: s.name, retailer: s.retailer })),
    pick: (text) => { const c = choose(text); return c.named ? c.chosen.map((s) => s.name) : []; },   // tên các gian được nêu trong câu (rỗng = không nêu)
    parseRange,

    // Kiểm THẬT từng gian: đăng nhập API, đọc chi nhánh, đọc hóa đơn hôm nay. Dùng cho tự chẩn đoán (báo Telegram khi hỏng) và /tuchan.
    async health(nowMs) {
      const res = await each(list, async (api) => {
        const b = await api.rawGet('/branches?pageSize=100');
        const from = vnDate(0, nowMs).iso, to = vnDate(1, nowMs).iso;
        const inv = await api.rawGet('/invoices?' + new URLSearchParams({ pageSize: '1', fromPurchaseDate: from, toPurchaseDate: to }).toString());
        return { branches: (b.data || []).length, invoicesToday: Number(inv.total) || 0 };
      });
      return res.map((r) => r.err ? { name: r.s.name, ok: false, soft: /429|giới hạn tốc độ|fetch failed|ETIMEDOUT|ECONNRESET|EAI_AGAIN/i.test(String(r.err)), detail: r.err } : { name: r.s.name, ok: true, detail: r.v.branches + ' chi nhánh, hôm nay ' + r.v.invoicesToday + ' hóa đơn' });
    },

    async rawGet(pathAndQuery, shop) {
      if (!list.length) throw new Error('Chưa cấu hình KiotViet.');
      let s;
      if (shop) { const c = choose(shop); s = c.named ? c.chosen[0] : null; if (!s) throw new Error('Không có gian hàng "' + shop + '". Đang có: ' + names()); }
      else if (list.length === 1) s = list[0];
      else throw new Error('Có ' + list.length + ' gian hàng KiotViet (' + names() + '): phải nói rõ gian nào (thêm --shop <tên>).');
      return s.api.rawGet(pathAndQuery);
    },

    async revenue(arg, nowMs) {
      if (!multi) return list.length ? list[0].api.revenue(arg, nowMs) : 'Chưa cấu hình KiotViet.';
      const q = splitRevenueQuery(arg, nowMs);
      const c = choose(q.filter);
      const sub = (q.range + ' ' + c.rest).trim();
      const res = await each(c.chosen, (api) => api.revenue(sub, nowMs));
      return res.map((r) => head(r.s) + '\n' + (r.err ? '⚠️ ' + r.err : r.v)).join('\n\n');
    },

    async stock(query) {
      if (!multi) return list.length ? list[0].api.stock(query) : 'Chưa cấu hình KiotViet.';
      const c = choose(query);
      const res = await each(c.chosen, (api) => api.stock(c.rest));
      return res.map((r) => head(r.s) + '\n' + (r.err ? '⚠️ ' + r.err : r.v)).join('\n\n');
    },

    async catalog(arg) {
      if (!multi) return list.length ? list[0].api.catalog(arg) : 'Chưa cấu hình KiotViet.';
      const c = choose(arg);
      const res = await each(c.chosen, (api) => api.catalog(c.rest));
      return res.map((r) => head(r.s) + '\n' + (r.err ? '⚠️ ' + r.err : r.v)).join('\n\n');
    },

    async products(query, limit) {
      const res = await each(list, (api) => api.products(query, limit));
      const out = [];
      for (const r of res) if (r.v) for (const p of r.v) out.push(multi ? Object.assign({}, p, { name: '[' + r.s.name + '] ' + p.name }) : p);
      return out;
    },

    async invoicesToday(nowMs) {
      const res = await each(list, (api) => api.invoicesToday(nowMs));
      const out = [];
      for (const r of res) if (r.v) for (const i of r.v) out.push(multi ? Object.assign({}, i, { id: r.s.idx + ':' + i.id, branchName: r.s.name + ' · ' + (i.branchName || '?') }) : i);
      return out;
    },

    async invoiceTotals(from, to) {
      const res = await each(list, (api) => api.invoiceTotals(from, to));
      const out = [];
      for (const r of res) if (r.v) for (const i of r.v) out.push(multi ? Object.assign({}, i, { id: r.s.idx + ':' + i.id, branchName: r.s.name + ' · ' + (i.branchName || '?') }) : i);
      return out;
    },

    async lowStock(limit, maxPages) {
      const res = await each(list, (api) => api.lowStock(limit, maxPages));
      let total = 0; const items = [];
      for (const r of res) if (r.v) { total += r.v.total; for (const i of r.v.items) items.push(multi ? Object.assign({}, i, { name: '[' + r.s.name + '] ' + i.name }) : i); }
      items.sort((a, b) => (a.onHand - a.min) - (b.onHand - b.min));
      return { total, items: items.slice(0, limit || 15) };
    },
  };
}

// Danh sách gian hàng từ cấu hình: KIOTVIET_SHOPS (JSON một dòng, do trang Cài đặt ghi) + bộ khóa cũ KIOTVIET_CLIENT_ID/SECRET/RETAILER (nếu chưa có trong danh sách).
function parseShops(env) {
  env = env || {};
  let arr = [];
  try { const j = JSON.parse(env.KIOTVIET_SHOPS || '[]'); if (Array.isArray(j)) arr = j; } catch (e) { arr = []; }
  const out = arr.map((s) => ({ name: String((s && s.name) || '').trim(), retailer: String((s && s.retailer) || '').trim(), clientId: String((s && s.clientId) || '').trim(), clientSecret: String((s && s.clientSecret) || '').trim() })).filter((s) => s.retailer && s.clientId && s.clientSecret);
  if (env.KIOTVIET_CLIENT_ID && env.KIOTVIET_CLIENT_SECRET && env.KIOTVIET_RETAILER && !out.some((s) => s.retailer.toLowerCase() === String(env.KIOTVIET_RETAILER).toLowerCase())) {
    out.unshift({ name: '', retailer: env.KIOTVIET_RETAILER, clientId: env.KIOTVIET_CLIENT_ID, clientSecret: env.KIOTVIET_CLIENT_SECRET });
  }
  return out;
}

module.exports = { createKiotViet, createMultiKiotViet, parseShops, splitRevenueQuery, parseRange, vnDate, noAccent, money, checkReadPath };
